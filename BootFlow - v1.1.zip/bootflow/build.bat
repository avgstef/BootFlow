@echo off
REM Redirect to the full packaging script
call "%~dp0packaging\build_windows.bat"

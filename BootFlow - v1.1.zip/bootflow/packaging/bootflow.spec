# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller Specification for BootFlow
Builds a standalone executable with complete QML assets, icons, and web companion UI.
"""

import sys
import os
from pathlib import Path

block_cipher = None

BASE_DIR = Path(SPECPATH).parent.resolve()
APP_DIR = BASE_DIR / "app"

# Bundle into both app/ and root levels so path resolution is 100% resilient
added_files = [
    (str(APP_DIR / "ui" / "qml"), "app/ui/qml"),
    (str(APP_DIR / "ui" / "qml"), "ui/qml"),
    (str(APP_DIR / "ui" / "web"), "app/ui/web"),
    (str(APP_DIR / "ui" / "web"), "ui/web"),
    (str(APP_DIR / "assets"), "app/assets"),
    (str(APP_DIR / "assets"), "assets"),
]

a = Analysis(
    [str(APP_DIR / "main.py")],
    pathex=[str(BASE_DIR), str(APP_DIR)],
    binaries=[],
    datas=added_files,
    hiddenimports=[
        "PySide6.QtCore",
        "PySide6.QtGui",
        "PySide6.QtWidgets",
        "PySide6.QtQuick",
        "PySide6.QtQml",
        "PySide6.QtNetwork",
        "PySide6.QtOpenGL",
        "app.ui.bridge",
        "app.core.scanner",
        "app.core.manager",
        "app.core.boot_diagnostics",
        "app.core.recommendations",
        "app.core.settings",
        "app.core.platform_compat",
        "app.core.models",
        "uvicorn",
        "fastapi",
        "starlette",
        "pydantic"
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "matplotlib",
        "scipy",
        "notebook",
        "IPython",
        "PySide6.QtWebEngineCore",
        "PySide6.QtWebEngineQuick",
        "PySide6.QtQuick3D",
        "PySide6.QtSpatialAudio",
        "PySide6.QtMultimedia",
        "PySide6.QtMultimediaQuick",
        "PySide6.QtBluetooth",
        "PySide6.QtNfc",
        "PySide6.QtSensors",
        "PySide6.QtSerialPort",
        "PySide6.QtTest",
        "PySide6.QtLocation",
        "PySide6.QtPositioning"
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="BootFlow",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(APP_DIR / "assets" / "icons" / "bootflow.ico"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="BootFlow",
)

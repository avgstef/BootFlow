# =========================================================================
# BootFlow - Windows PowerShell Build Script
# Automatically locates Python across PATH, py launcher, and default paths
# =========================================================================

# Ensure working directory is project root
$rootDir = Split-Path -Parent $PSScriptRoot
if (Test-Path "$rootDir/requirements.txt") {
    Set-Location $rootDir
}

Write-Host "`n============================================================" -ForegroundColor Cyan
Write-Host "  BootFlow - Standalone Windows Executable Builder" -ForegroundColor Cyan
Write-Host "============================================================`n" -ForegroundColor Cyan

Write-Host ">>> [1/4] Detecting Python installation..." -ForegroundColor Cyan

$pythonCmd = $null

# 1. Test py launcher
if (Get-Command py -ErrorAction SilentlyContinue) {
    try {
        & py -3 -c "import sys; print(sys.executable)" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $pythonCmd = "py -3"
        }
    } catch {}
}

# 2. Test python command
if (-not $pythonCmd -and (Get-Command python -ErrorAction SilentlyContinue)) {
    try {
        & python -c "import sys; print(sys.executable)" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $pythonCmd = "python"
        }
    } catch {}
}

# 3. Test python3 command
if (-not $pythonCmd -and (Get-Command python3 -ErrorAction SilentlyContinue)) {
    try {
        & python3 -c "import sys; print(sys.executable)" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $pythonCmd = "python3"
        }
    } catch {}
}

# 4. Search common installation directories
if (-not $pythonCmd) {
    $searchPaths = @(
        "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe",
        "C:\Program Files\Python314\python.exe",
        "C:\Program Files\Python313\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        "C:\Program Files\Python310\python.exe",
        "C:\Python313\python.exe",
        "C:\Python312\python.exe",
        "C:\Python311\python.exe",
        "C:\Python310\python.exe"
    )
    foreach ($p in $searchPaths) {
        if (Test-Path $p) {
            $pythonCmd = "`"$p`""
            break
        }
    }
}

if (-not $pythonCmd) {
    Write-Host "`n[!] Python was not detected in PATH or standard installation folders." -ForegroundColor Yellow
    Write-Host "    (This occurs when 'Add python.exe to PATH' was not checked during installation.)`n" -ForegroundColor Yellow
    $userPath = Read-Host "Enter the full path to your python.exe (or press Enter to exit)"
    if ($userPath -and (Test-Path $userPath)) {
        $pythonCmd = "`"$userPath`""
    } else {
        Write-Host "`n============================================================" -ForegroundColor Red
        Write-Host "QUICK FIX (takes 30 seconds):" -ForegroundColor White
        Write-Host "1. Open your Python installer or download it from https://python.org"
        Write-Host "2. Choose 'Modify' or reinstall"
        Write-Host "3. Check: [X] 'Add python.exe to PATH'"
        Write-Host "4. Re-run this build script!`n"
        Write-Host "============================================================" -ForegroundColor Red
        exit 1
    }
}

Write-Host "[OK] Using Python: $pythonCmd" -ForegroundColor Green
Invoke-Expression "$pythonCmd --version"

Write-Host "`n>>> [2/4] Installing / Upgrading build requirements..." -ForegroundColor Cyan
Invoke-Expression "$pythonCmd -m pip install --upgrade pip"
Invoke-Expression "$pythonCmd -m pip install -r requirements.txt pyinstaller"

Write-Host "`n>>> [3/4] Running automated tests..." -ForegroundColor Cyan
Invoke-Expression "$pythonCmd -m pytest tests -q"

Write-Host "`n>>> [4/4] Building standalone Windows executable..." -ForegroundColor Cyan
Invoke-Expression "$pythonCmd -m PyInstaller --clean -y packaging/bootflow.spec"

if ($LASTEXITCODE -eq 0) {
    Write-Host "`n============================================================" -ForegroundColor Green
    Write-Host "[SUCCESS] Standalone BootFlow executable generated!" -ForegroundColor Green
    Write-Host "Binary Location: dist\BootFlow\BootFlow.exe" -ForegroundColor Yellow
    Write-Host "============================================================`n" -ForegroundColor Green
} else {
    Write-Error "PyInstaller packaging failed with exit code $LASTEXITCODE."
    exit $LASTEXITCODE
}

@echo off
setlocal enabledelayedexpansion

:: =========================================================================
:: BootFlow - Standalone Windows Executable Builder
:: Automatically locates Python across PATH, py launcher, and default paths
:: =========================================================================

:: Ensure working directory is the project root
cd /d "%~dp0.."
if not exist "requirements.txt" (
    cd /d "%~dp0"
)

echo ============================================================
echo   BootFlow - Standalone Windows Executable Builder
echo ============================================================
echo.
echo [1/4] Detecting Python installation...

set "PYTHON_CMD="

:: 1. Check Python Launcher 'py' (installed into C:\Windows\py.exe by standard python.org installer)
where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    py -3 -c "import sys; print(sys.executable)" >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD=py -3"
        goto :FOUND_PYTHON
    )
)

:: 2. Check 'python' in system PATH
where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    python -c "import sys; print(sys.executable)" >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD=python"
        goto :FOUND_PYTHON
    )
)

:: 3. Check 'python3' in system PATH
where python3 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    python3 -c "import sys; print(sys.executable)" >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD=python3"
        goto :FOUND_PYTHON
    )
)

:: 4. Check common per-user installation folders (AppData\Local\Programs\Python)
for %%V in (314 313 312 311 310 39) do (
    if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set "PYTHON_CMD="%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe""
        goto :FOUND_PYTHON
    )
    if exist "%ProgramFiles%\Python%%V\python.exe" (
        set "PYTHON_CMD="%ProgramFiles%\Python%%V\python.exe""
        goto :FOUND_PYTHON
    )
    if exist "%ProgramFiles(x86)%\Python%%V\python.exe" (
        set "PYTHON_CMD="%ProgramFiles(x86)%\Python%%V\python.exe""
        goto :FOUND_PYTHON
    )
    if exist "C:\Python%%V\python.exe" (
        set "PYTHON_CMD="C:\Python%%V\python.exe""
        goto :FOUND_PYTHON
    )
)

:: 5. Check Microsoft Store / WindowsApps python stub
if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" (
    "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" -c "import sys" >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set "PYTHON_CMD="%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe""
        goto :FOUND_PYTHON
    )
)

:: 6. If not detected automatically, ask the user for the custom path
echo.
echo [!] Python was not found in your system PATH or default directories.
echo     (This happens when 'Add python.exe to PATH' was not checked during Python setup.)
echo.
set /p "CUSTOM_PY=Enter the full path to your python.exe (or press Enter to exit): "

if defined CUSTOM_PY (
    set "CUSTOM_PY=!CUSTOM_PY:"=!"
    if exist "!CUSTOM_PY!" (
        set "PYTHON_CMD="!CUSTOM_PY!""
        goto :FOUND_PYTHON
    ) else (
        echo [ERROR] The file "!CUSTOM_PY!" was not found.
    )
)

echo.
echo ============================================================
echo   QUICK FIX (takes 30 seconds):
echo   1. Re-run your Python installer (or get it from https://python.org).
echo   2. Choose "Modify" or install.
echo   3. CHECK THE BOX: [X] "Add python.exe to PATH"
echo   4. Re-open this script!
echo ============================================================
echo.
pause
exit /b 1

:FOUND_PYTHON
echo [OK] Found Python interpreter: !PYTHON_CMD!
!PYTHON_CMD! --version
echo.

echo [2/4] Installing / Verifying requirements and PyInstaller...
!PYTHON_CMD! -m pip install --upgrade pip
!PYTHON_CMD! -m pip install -r requirements.txt pyinstaller
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install dependencies via pip.
    pause
    exit /b 1
)

echo.
echo [3/4] Running automated test suite...
!PYTHON_CMD! -m pytest tests -q
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] One or more tests reported warnings, continuing packaging...
)

echo.
echo [4/4] Building standalone Windows binary with PyInstaller...
!PYTHON_CMD! -m PyInstaller --clean -y packaging\bootflow.spec
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] PyInstaller build failed.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   [SUCCESS] BootFlow executable built successfully!
echo   Location: dist\BootFlow\BootFlow.exe
echo ============================================================
echo.
pause

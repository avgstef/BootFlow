import math
from PIL import Image, ImageDraw, ImageFilter

def create_bootflow_icon(size=512):
    # Create image with transparent background
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Padding and geometry
    pad = size * 0.08
    w = size - 2 * pad
    h = size - 2 * pad

    # Draw soft outer glow shadow
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow)
    glow_box = [pad - 4, pad - 2, pad + w + 4, pad + h + 8]
    glow_draw.rounded_rectangle(glow_box, radius=size * 0.24, fill=(139, 128, 249, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(size * 0.05))
    img.alpha_composite(glow)

    # Main squircle background with vertical gradient (soft periwinkle to lavender to subtle navy)
    # We will create a gradient canvas
    grad = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    grad_draw = ImageDraw.Draw(grad)

    for y in range(int(pad), int(pad + h)):
        t = (y - pad) / h
        # Gradient from #EEF2FF to #E0E7FF with hint of violet
        r = int(248 * (1 - t) + 238 * t)
        g = int(250 * (1 - t) + 242 * t)
        b = int(255 * (1 - t) + 255 * t)
        grad_draw.line([(pad, y), (pad + w, y)], fill=(r, g, b, 255))

    # Mask for squircle
    mask = Image.new("L", (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.rounded_rectangle([pad, pad, pad + w, pad + h], radius=size * 0.22, fill=255)

    # Composite rounded base
    bg_rounded = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    bg_rounded.paste(grad, (0, 0), mask)
    img.alpha_composite(bg_rounded)

    # Inner delicate border / glass highlight
    border_img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    border_draw = ImageDraw.Draw(border_img)
    border_draw.rounded_rectangle([pad, pad, pad + w, pad + h], radius=size * 0.22, outline=(255, 255, 255, 230), width=int(size * 0.012))
    img.alpha_composite(border_img)

    # Decorative ambient glow circles inside squircle
    ambient = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    amb_draw = ImageDraw.Draw(ambient)
    amb_draw.ellipse([pad + w * 0.45, pad + h * 0.05, pad + w * 1.15, pad + h * 0.75], fill=(139, 128, 249, 90))
    amb_draw.ellipse([pad - w * 0.1, pad + h * 0.4, pad + w * 0.55, pad + h * 1.05], fill=(56, 189, 248, 70))
    ambient = ambient.filter(ImageFilter.GaussianBlur(size * 0.07))
    ambient_masked = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ambient_masked.paste(ambient, (0, 0), mask)
    img.alpha_composite(ambient_masked)

    # Foreground Icon: The "BootFlow" emblem
    # A sleek futuristic dual-curve startup flow shape (resembling a fast forward pulse / B-wing)
    fg = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    fg_draw = ImageDraw.Draw(fg)

    # Center coordinates
    cx = size * 0.5
    cy = size * 0.5

    # 1. Back wave (cyan-to-lavender)
    # Primary forward flow stroke (a stylized fast boot swoosh)
    path_points = [
        (cx - size * 0.22, cy + size * 0.20),
        (cx - size * 0.10, cy + size * 0.20),
        (cx + size * 0.12, cy + size * 0.04),
        (cx + size * 0.22, cy - size * 0.16),
        (cx + size * 0.10, cy - size * 0.16),
        (cx - size * 0.06, cy - size * 0.02),
        (cx - size * 0.22, cy + size * 0.08),
    ]
    # Draw smooth multi-layered polygons / pill ribbons
    # Let's draw three dynamic aerodynamic flow blades with rounded caps
    # Blade 1 (top):
    b1_pts = [
        (cx - size * 0.18, cy - size * 0.18),
        (cx + size * 0.08, cy - size * 0.18),
        (cx + size * 0.22, cy - size * 0.06),
        (cx + size * 0.12, cy - size * 0.06),
        (cx - size * 0.02, cy - size * 0.18),
    ]

    # Let's use high quality drawing:
    # A startup spark / flow accelerator:
    # Left vertical energetic bar, and two curved flow wings
    # Bar:
    bar_x = cx - size * 0.18
    bar_y1 = cy - size * 0.22
    bar_y2 = cy + size * 0.22
    bar_w = size * 0.09
    fg_draw.rounded_rectangle([bar_x, bar_y1, bar_x + bar_w, bar_y2], radius=bar_w * 0.5, fill=(124, 58, 237, 255))

    # Upper flow jet:
    jet1_x1 = bar_x + bar_w * 0.6
    jet1_y1 = cy - size * 0.22
    jet1_x2 = cx + size * 0.22
    jet1_y2 = cy - size * 0.04
    fg_draw.rounded_rectangle([jet1_x1, jet1_y1, jet1_x2, jet1_y2], radius=(jet1_y2 - jet1_y1) * 0.45, fill=(139, 128, 249, 255))

    # Lower flow jet (accelerating forward):
    jet2_x1 = bar_x + bar_w * 0.6
    jet2_y1 = cy + size * 0.04
    jet2_x2 = cx + size * 0.26
    jet2_y2 = cy + size * 0.22
    fg_draw.rounded_rectangle([jet2_x1, jet2_y1, jet2_x2, jet2_y2], radius=(jet2_y2 - jet2_y1) * 0.45, fill=(56, 189, 248, 255))

    # Center flow circle / pulse
    pulse_r = size * 0.065
    fg_draw.ellipse([cx - pulse_r * 0.3, cy - pulse_r, cx + pulse_r * 1.7, cy + pulse_r], fill=(255, 255, 255, 255))
    fg_draw.ellipse([cx - pulse_r * 0.1, cy - pulse_r * 0.8, cx + pulse_r * 1.5, cy + pulse_r * 0.8], fill=(139, 128, 249, 255))
    fg_draw.ellipse([cx + pulse_r * 0.3, cy - pulse_r * 0.4, cx + pulse_r * 1.1, cy + pulse_r * 0.4], fill=(255, 255, 255, 255))

    # Subtle drop shadow on the foreground emblem
    fg_shadow = fg.filter(ImageFilter.GaussianBlur(size * 0.02))
    shadow_layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    shadow_layer.paste((20, 20, 60, 50), (0, int(size * 0.015)), fg_shadow.split()[3])
    img.alpha_composite(shadow_layer)
    img.alpha_composite(fg)

    return img

icon_512 = create_bootflow_icon(512)
icon_512.save("/home/user/bootflow/app/assets/icons/bootflow_icon.png")

# Generate multi-size .ico
icon_sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
icon_layers = [icon_512.resize(s, Image.Resampling.LANCZOS) for s in icon_sizes]
icon_layers[0].save(
    "/home/user/bootflow/app/assets/icons/bootflow.ico",
    format="ICO",
    sizes=icon_sizes,
    append_images=icon_layers[1:]
)

print("Icons created successfully!")

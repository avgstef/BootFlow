"""
BootFlow - PySide6 QML Bridge
Exposes Python backend core logic, scanner, manager, and diagnostics to QML.
"""

import sys
import logging
from typing import List, Dict, Any
from PySide6.QtCore import QObject, Signal, Slot, Property

from ..core.scanner import StartupScanner
from ..core.manager import StartupManager
from ..core.boot_diagnostics import BootDiagnostics
from ..core.recommendations import RecommendationsEngine
from ..core.settings import SettingsManager
from ..core.platform_compat import get_windows_version_string, is_windows

logger = logging.getLogger("bootflow.bridge")

class BootFlowBridge(QObject):
    dataRefreshed = Signal()
    scanStarted = Signal()
    scanCompleted = Signal()
    itemToggled = Signal(str, bool)
    toastMessage = Signal(str, str) # message, type

    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings_mgr = SettingsManager()
        self.scanner = StartupScanner(self.settings_mgr)
        self.manager = StartupManager(self.settings_mgr)
        self.diagnostics = BootDiagnostics(self.settings_mgr)
        self.recommendations_engine = RecommendationsEngine(self.settings_mgr)

        self._items: List[Dict[str, Any]] = []
        self._recommendations: List[Dict[str, Any]] = []
        self._boot_history: List[Dict[str, Any]] = []
        self._system_status: Dict[str, Any] = {}
        self._boot_stats: Dict[str, Any] = {}
        self._activity_log: List[Dict[str, Any]] = []

        self.refreshData()

    @Slot()
    def refreshData(self):
        """Refreshes all backend datasets and emits dataRefreshed."""
        try:
            items_raw = self.scanner.scan_all()
            self._items = [i.to_dict() for i in items_raw]

            recs_raw = self.recommendations_engine.generate_recommendations(items_raw)
            self._recommendations = [r.to_dict() for r in recs_raw]

            history_raw = self.diagnostics.get_boot_history(limit=30)
            self._boot_history = [m.to_dict() for m in history_raw]
            self._boot_stats = self.diagnostics.compute_summary_statistics(history_raw)

            health = self.recommendations_engine.evaluate_system_health(items_raw)
            latest = self.diagnostics.get_latest_boot_metric()

            self._system_status = {
                "platform": get_windows_version_string(),
                "is_windows": is_windows(),
                "health": health.to_dict(),
                "latest_boot": latest.to_dict() if latest else None,
                "boot_stats": self._boot_stats,
                "total_items": len(self._items),
                "enabled_count": health.enabled_count,
                "disabled_count": health.disabled_count,
                "high_impact_count": health.high_impact_count
            }

            activities = self.settings_mgr.get_recent_activity(limit=15)
            self._activity_log = [a.to_dict() for a in activities]

            self.dataRefreshed.emit()
        except Exception as e:
            logger.error(f"Error in refreshData: {e}")
            self.toastMessage.emit(f"Refresh error: {e}", "danger")

    @Slot()
    def runScan(self):
        self.scanStarted.emit()
        self.refreshData()
        self.scanCompleted.emit()
        self.toastMessage.emit("Startup analysis completed successfully.", "success")

    @Slot(str, bool, result=bool)
    def toggleItem(self, item_id: str, enabled: bool) -> bool:
        items = self.scanner.scan_all()
        target = next((i for i in items if i.id == item_id), None)
        if not target:
            self.toastMessage.emit("Item not found.", "danger")
            return False

        success, msg = self.manager.set_item_status(target, enabled)
        if success:
            self.toastMessage.emit(msg, "success")
            self.refreshData()
            self.itemToggled.emit(item_id, enabled)
            return True
        else:
            self.toastMessage.emit(msg, "danger")
            return False

    @Slot(str, result=bool)
    def applyRecommendation(self, rec_id: str) -> bool:
        items = self.scanner.scan_all()
        recs = self.recommendations_engine.generate_recommendations(items)
        target_rec = next((r for r in recs if r.id == rec_id), None)
        if target_rec and target_rec.target_item_id:
            target_item = next((i for i in items if i.id == target_rec.target_item_id), None)
            if target_item:
                success, msg = self.manager.set_item_status(target_item, False)
                self.settings_mgr.dismiss_recommendation(rec_id)
                self.toastMessage.emit(msg, "success")
                self.refreshData()
                return success
        self.settings_mgr.dismiss_recommendation(rec_id)
        self.refreshData()
        return True

    @Slot(str, result=bool)
    def dismissRecommendation(self, rec_id: str) -> bool:
        self.settings_mgr.dismiss_recommendation(rec_id)
        self.refreshData()
        self.toastMessage.emit("Recommendation dismissed.", "success")
        return True

    @Slot(str, result=str)
    def getSetting(self, key: str) -> str:
        return str(self.settings_mgr.get(key, ""))

    @Slot(str, str)
    def setSetting(self, key: str, value: str):
        self.settings_mgr.set(key, value)

    @Slot(result=bool)
    def clearHistory(self) -> bool:
        success = self.settings_mgr.clear_database_history()
        self.refreshData()
        self.toastMessage.emit("Local history cleared.", "success")
        return success

    # Properties for QML bindings
    @Property(list, notify=dataRefreshed)
    def startupItems(self) -> list:
        return self._items

    @Property(list, notify=dataRefreshed)
    def recommendations(self) -> list:
        return self._recommendations

    @Property(list, notify=dataRefreshed)
    def bootHistory(self) -> list:
        return self._boot_history

    @Property(dict, notify=dataRefreshed)
    def systemStatus(self) -> dict:
        return self._system_status

    @Property(dict, notify=dataRefreshed)
    def bootStats(self) -> dict:
        return self._boot_stats

    @Property(list, notify=dataRefreshed)
    def activityLog(self) -> list:
        return self._activity_log

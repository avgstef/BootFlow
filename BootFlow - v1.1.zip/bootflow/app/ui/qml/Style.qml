pragma Singleton
import QtQuick 2.15

QtObject {
    id: style

    // Brand Palette
    readonly property color primary: "#8B80F9"
    readonly property color primaryHover: "#7A6EF5"
    readonly property color primaryLight: "#1F8B80F9" // ~12% opacity
    readonly property color primaryBorder: "#408B80F9"

    readonly property color periwinkle: "#A5B4FC"
    readonly property color periwinkleLight: "#26A5B4FC"

    readonly property color secondary: "#38BDF8"
    readonly property color secondaryHover: "#0284C7"

    // Semantic Status Colors
    readonly property color success: "#10B981"
    readonly property color successBg: "#1A10B981"
    readonly property color successBorder: "#4010B981"

    readonly property color warning: "#F59E0B"
    readonly property color warningBg: "#1AF59E0B"
    readonly property color warningBorder: "#40F59E0B"

    readonly property color danger: "#EF4444"
    readonly property color dangerBg: "#1AEF4444"
    readonly property color dangerBorder: "#40EF4444"

    // Surfaces (Dark Theme 2.0 by default)
    property bool isDark: true

    readonly property color bgApp: isDark ? "#0B0F19" : "#F5F7FC"
    readonly property color bgSidebar: isDark ? "#D9121826" : "#E6FFFFFF"
    readonly property color bgCard: isDark ? "#C0171E30" : "#D4FFFFFF"
    readonly property color bgCardHover: isDark ? "#D91E273E" : "#F2FFFFFF"
    readonly property color bgInput: isDark ? "#D9121826" : "#D9F8FAFC"

    // Borders & Dividers
    readonly property color borderLight: isDark ? "#14FFFFFF" : "#CCE2E8F0"
    readonly property color borderHighlight: isDark ? "#20FFFFFF" : "#E6FFFFFF"

    // Typography Colors
    readonly property color textMain: isDark ? "#F8FAFC" : "#0F172A"
    readonly property color textSecondary: isDark ? "#CBD5E1" : "#334155"
    readonly property color textMuted: isDark ? "#94A3B8" : "#64748B"
    readonly property color textLight: isDark ? "#64748B" : "#94A3B8"

    // Typography Font
    readonly property string fontFamily: "Inter, Segoe UI, -apple-system, sans-serif"

    // Geometry Radii
    readonly property int radiusSm: 8
    readonly property int radiusMd: 12
    readonly property int radiusLg: 18
    readonly property int radiusXl: 24
    readonly property int radiusPill: 9999

    // Animation Timings
    readonly property int animFast: 150
    readonly property int animNormal: 250
    readonly property int animSmooth: 350
}

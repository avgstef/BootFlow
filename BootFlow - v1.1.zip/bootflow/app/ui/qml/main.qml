import QtQuick 2.15
import QtQuick.Controls 2.15
import "." 1.0
import "components" 1.0
import "views" 1.0

ApplicationWindow {
    id: window
    width: 1180
    height: 780
    minimumWidth: 900
    minimumHeight: 600
    visible: true
    title: "BootFlow — Windows Startup Optimization"
    color: Style.bgApp

    // Ambient Glow simulation in QML
    Rectangle {
        width: 500
        height: 500
        radius: 250
        x: window.width - 250
        y: -100
        color: Style.isDark ? "#108B80F9" : "#1A8B80F9"
    }

    Rectangle {
        width: 500
        height: 500
        radius: 250
        x: -150
        y: window.height - 250
        color: Style.isDark ? "#0A38BDF8" : "#1438BDF8"
    }

    Row {
        anchors.fill: parent

        // Sidebar Navigation
        Sidebar {
            id: sidebar
            height: parent.height
            currentPage: stackLayout.currentPageId
            onPageSelected: {
                stackLayout.currentPageId = pageId
            }
        }

        // Main Content Area
        Item {
            width: parent.width - sidebar.width
            height: parent.height

            Column {
                anchors.fill: parent
                anchors.leftMargin: 32
                anchors.rightMargin: 32
                anchors.bottomMargin: 32

                TopBar {
                    width: parent.width
                    pageTitle: {
                        if (stackLayout.currentPageId === "dashboard") return "Overview";
                        if (stackLayout.currentPageId === "startup-apps") return "Startup Apps";
                        if (stackLayout.currentPageId === "boot-analysis") return "Boot Analysis";
                        if (stackLayout.currentPageId === "recommendations") return "Recommendations";
                        return "Settings";
                    }
                    onScanClicked: {
                        if (bridge) bridge.runScan()
                    }
                }

                Item {
                    id: stackLayout
                    width: parent.width
                    height: parent.height - 70
                    property string currentPageId: "dashboard"

                    DashboardView {
                        anchors.fill: parent
                        visible: stackLayout.currentPageId === "dashboard"
                    }

                    StartupAppsView {
                        anchors.fill: parent
                        visible: stackLayout.currentPageId === "startup-apps"
                    }

                    BootAnalysisView {
                        anchors.fill: parent
                        visible: stackLayout.currentPageId === "boot-analysis"
                    }

                    RecommendationsView {
                        anchors.fill: parent
                        visible: stackLayout.currentPageId === "recommendations"
                    }

                    SettingsView {
                        anchors.fill: parent
                        visible: stackLayout.currentPageId === "settings"
                    }
                }
            }
        }
    }
}

import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0

Rectangle {
    id: root
    width: 250
    color: Style.bgSidebar
    border.color: Style.borderLight
    border.width: 1

    property string currentPage: "dashboard"
    signal pageSelected(string pageId)

    Column {
        anchors.fill: parent
        anchors.margins: 20
        spacing: 16

        // Brand Row
        Row {
            spacing: 12
            Rectangle {
                width: 36
                height: 36
                radius: 10
                color: Style.primary
                Text {
                    anchors.centerIn: parent
                    text: "BF"
                    color: "white"
                    font.bold: true
                    font.pixelSize: 14
                }
            }
            Column {
                anchors.verticalCenter: parent.verticalCenter
                Text {
                    text: "BootFlow"
                    font.family: Style.fontFamily
                    font.pixelSize: 19
                    font.bold: true
                    color: Style.textMain
                }
                Text {
                    text: "STARTUP ENGINE"
                    font.family: Style.fontFamily
                    font.pixelSize: 8
                    font.bold: true
                    color: Style.textMuted
                }
            }
        }

        Item { width: 1; height: 10 } // Spacer

        // Nav items
        Repeater {
            model: [
                { id: "dashboard", label: "Overview", icon: "❖" },
                { id: "startup-apps", label: "Startup Apps", icon: "⚡" },
                { id: "boot-analysis", label: "Boot Analysis", icon: "📈" },
                { id: "recommendations", label: "Recommendations", icon: "💡" },
                { id: "settings", label: "Settings", icon: "⚙" }
            ]

            Rectangle {
                width: parent.width
                height: 42
                radius: Style.radiusMd
                color: root.currentPage === modelData.id ? Style.primaryLight : "transparent"
                border.color: root.currentPage === modelData.id ? Style.primaryBorder : "transparent"
                border.width: 1

                Row {
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 14
                    spacing: 12
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: modelData.icon
                        font.pixelSize: 15
                        color: root.currentPage === modelData.id ? Style.primary : Style.textMuted
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: modelData.label
                        font.family: Style.fontFamily
                        font.pixelSize: 13
                        font.bold: root.currentPage === modelData.id
                        color: root.currentPage === modelData.id ? Style.primary : Style.textSecondary
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.pageSelected(modelData.id)
                }
            }
        }

        Item { width: 1; height: 30 } // Spacer
    }
}

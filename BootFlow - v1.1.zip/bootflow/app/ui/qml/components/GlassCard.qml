import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0

Rectangle {
    id: root
    radius: Style.radiusLg
    color: Style.bgCard
    border.color: mouseArea.containsMouse ? Style.primaryBorder : Style.borderLight
    border.width: 1

    property alias hovered: mouseArea.containsMouse

    Behavior on border.color {
        ColorAnimation { duration: Style.animFast }
    }

    Behavior on color {
        ColorAnimation { duration: Style.animFast }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
    }
}

import QtQuick 2.15
import ".." 1.0

Item {
    id: root
    width: 44
    height: 24

    property bool checked: false
    signal toggled(bool newState)

    Rectangle {
        id: track
        anchors.fill: parent
        radius: Style.radiusPill
        color: root.checked ? Style.primary : "#4D94A3B8"

        Behavior on color {
            ColorAnimation { duration: Style.animFast }
        }

        Rectangle {
            id: thumb
            width: 18
            height: 18
            radius: 9
            color: "#FFFFFF"
            anchors.verticalCenter: parent.verticalCenter
            x: root.checked ? (parent.width - width - 3) : 3

            Behavior on x {
                NumberAnimation { duration: Style.animFast; easing.type: Easing.OutQuad }
            }
        }
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            root.checked = !root.checked
            root.toggled(root.checked)
        }
    }
}

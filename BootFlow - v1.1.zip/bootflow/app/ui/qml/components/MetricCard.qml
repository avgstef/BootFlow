import QtQuick 2.15
import ".." 1.0

GlassCard {
    id: root
    width: 220
    height: 130

    property string label: "Metric"
    property string value: "0"
    property string caption: ""
    property string badgeText: ""
    property color badgeColor: Style.primary

    Column {
        anchors.fill: parent
        anchors.margins: 18
        spacing: 8

        Row {
            width: parent.width
            Text {
                text: root.label
                font.family: Style.fontFamily
                font.pixelSize: 13
                color: Style.textMuted
                width: parent.width - 24
            }
        }

        Text {
            text: root.value
            font.family: Style.fontFamily
            font.pixelSize: 28
            font.weight: Font.Bold
            color: Style.textMain
        }

        Text {
            text: root.caption
            font.family: Style.fontFamily
            font.pixelSize: 11
            color: Style.textMuted
        }
    }
}

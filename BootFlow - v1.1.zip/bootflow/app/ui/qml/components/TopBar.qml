import QtQuick 2.15
import ".." 1.0

Item {
    id: root
    height: 70

    property string pageTitle: "Overview"
    property string pageSubtitle: "Real-time Windows startup diagnostics and performance breakdown"
    signal scanClicked()

    Row {
        anchors.left: parent.left
        anchors.verticalCenter: parent.verticalCenter
        spacing: 16

        Column {
            Text {
                text: root.pageTitle
                font.family: Style.fontFamily
                font.pixelSize: 22
                font.bold: true
                color: Style.textMain
            }
            Text {
                text: root.pageSubtitle
                font.family: Style.fontFamily
                font.pixelSize: 12
                color: Style.textMuted
            }
        }
    }

    Rectangle {
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        width: 110
        height: 36
        radius: Style.radiusPill
        color: Style.primary
        Row {
            anchors.centerIn: parent
            spacing: 6
            Text {
                text: "⟳"
                font.pixelSize: 14
                color: "white"
            }
            Text {
                text: "Scan Now"
                font.family: Style.fontFamily
                font.pixelSize: 13
                font.bold: true
                color: "white"
            }
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: root.scanClicked()
        }
    }
}

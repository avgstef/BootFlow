import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0
import "../components" 1.0

Flickable {
    id: root
    contentWidth: width
    contentHeight: contentCol.height + 40
    clip: true

    Column {
        id: contentCol
        width: parent.width
        spacing: 20

        // Hero Card
        GlassCard {
            width: parent.width
            height: 160
            color: Style.isDark ? "#201E293B" : "#F0F4FF"

            Row {
                anchors.fill: parent
                anchors.margins: 24
                spacing: 20

                Column {
                    width: parent.width - 200
                    spacing: 8

                    Rectangle {
                        width: 170
                        height: 24
                        radius: Style.radiusPill
                        color: Style.primaryLight
                        Text {
                            anchors.centerIn: parent
                            text: "Startup Optimization Engine"
                            font.pixelSize: 11
                            font.bold: true
                            color: Style.primary
                        }
                    }

                    Text {
                        text: "Your PC, ready sooner."
                        font.family: Style.fontFamily
                        font.pixelSize: 24
                        font.bold: true
                        color: Style.textMain
                    }

                    Text {
                        text: "BootFlow monitors Windows Diagnostics-Performance Event 100 to optimize your logon latency."
                        font.family: Style.fontFamily
                        font.pixelSize: 13
                        color: Style.textSecondary
                        wrapMode: Text.WordWrap
                        width: parent.width
                    }
                }

                // Measured Boot Orb
                Rectangle {
                    width: 110
                    height: 110
                    radius: 55
                    color: Style.bgCard
                    border.color: Style.primaryBorder
                    border.width: 2
                    anchors.verticalCenter: parent.verticalCenter

                    Column {
                        anchors.centerIn: parent
                        spacing: 2
                        Text {
                            text: "LATEST BOOT"
                            font.pixelSize: 8
                            font.bold: true
                            color: Style.textMuted
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                        Text {
                            text: "13.8s"
                            font.pixelSize: 22
                            font.bold: true
                            color: Style.textMain
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                        Text {
                            text: "▼ 1.4s faster"
                            font.pixelSize: 9
                            font.bold: true
                            color: Style.success
                            anchors.horizontalCenter: parent.horizontalCenter
                        }
                    }
                }
            }
        }

        // 4 Summary Metrics
        Grid {
            width: parent.width
            columns: 4
            spacing: 16

            MetricCard {
                width: (parent.width - 48) / 4
                label: "Enabled Apps"
                value: bridge ? String(bridge.systemStatus.enabled_count || 7) : "7"
                caption: "Autostarting at logon"
            }

            MetricCard {
                width: (parent.width - 48) / 4
                label: "Disabled Apps"
                value: bridge ? String(bridge.systemStatus.disabled_count || 4) : "4"
                caption: "Prevented from boot"
            }

            MetricCard {
                width: (parent.width - 48) / 4
                label: "High Startup Impact"
                value: bridge ? String(bridge.systemStatus.high_impact_count || 3) : "3"
                caption: "Contributing >1.0s each"
            }

            MetricCard {
                width: (parent.width - 48) / 4
                label: "Startup Health"
                value: bridge ? (bridge.systemStatus.health ? bridge.systemStatus.health.grade : "Optimal") : "Optimal"
                caption: "Kernel Telemetry Active"
            }
        }

        // Performance & Health split row
        Row {
            width: parent.width
            spacing: 20

            GlassCard {
                width: parent.width * 0.62
                height: 240

                Column {
                    anchors.fill: parent
                    anchors.margins: 18
                    spacing: 12

                    Text {
                        text: "Startup Performance Trend"
                        font.family: Style.fontFamily
                        font.pixelSize: 16
                        font.bold: true
                        color: Style.textMain
                    }

                    Text {
                        text: "Boot durations recorded by Windows Diagnostics-Performance (Event ID 100)"
                        font.pixelSize: 12
                        color: Style.textMuted
                    }

                    // Canvas Spline Chart
                    Canvas {
                        id: bootCanvas
                        width: parent.width
                        height: 130
                        onPaint: {
                            var ctx = getContext("2d");
                            ctx.clearRect(0, 0, width, height);

                            var data = [18.4, 17.9, 16.8, 16.1, 15.2, 14.4, 13.8];
                            var min = 12.0;
                            var max = 20.0;
                            var stepX = width / (data.length - 1);

                            // Gradient
                            var grad = ctx.createLinearGradient(0, 0, 0, height);
                            grad.addColorStop(0, "rgba(139, 128, 249, 0.35)");
                            grad.addColorStop(1, "rgba(139, 128, 249, 0.0)");

                            ctx.beginPath();
                            ctx.moveTo(0, height - ((data[0] - min)/(max - min))*height);
                            for (var i = 1; i < data.length; i++) {
                                var x = i * stepX;
                                var y = height - ((data[i] - min)/(max - min))*height;
                                ctx.lineTo(x, y);
                            }
                            ctx.lineTo(width, height);
                            ctx.lineTo(0, height);
                            ctx.closePath();
                            ctx.fillStyle = grad;
                            ctx.fill();

                            // Stroke
                            ctx.beginPath();
                            ctx.moveTo(0, height - ((data[0] - min)/(max - min))*height);
                            for (var j = 1; j < data.length; j++) {
                                var x2 = j * stepX;
                                var y2 = height - ((data[j] - min)/(max - min))*height;
                                ctx.lineTo(x2, y2);
                            }
                            ctx.strokeStyle = "#8B80F9";
                            ctx.lineWidth = 3;
                            ctx.stroke();
                        }
                    }
                }
            }

            GlassCard {
                width: parent.width * 0.38 - 20
                height: 240

                Column {
                    anchors.fill: parent
                    anchors.margins: 18
                    spacing: 12

                    Text {
                        text: "Startup Health Assessment"
                        font.family: Style.fontFamily
                        font.pixelSize: 16
                        font.bold: true
                        color: Style.textMain
                    }

                    Row {
                        spacing: 14
                        Rectangle {
                            width: 64
                            height: 64
                            radius: 32
                            color: Style.primaryLight
                            border.color: Style.success
                            border.width: 3
                            Text {
                                anchors.centerIn: parent
                                text: "84"
                                font.pixelSize: 22
                                font.bold: true
                                color: Style.textMain
                            }
                        }
                        Column {
                            anchors.verticalCenter: parent.verticalCenter
                            Text {
                                text: "Optimal Balance"
                                font.bold: true
                                font.pixelSize: 15
                                color: Style.textMain
                            }
                            Text {
                                text: "Top 15% responsiveness"
                                font.pixelSize: 12
                                color: Style.textMuted
                            }
                        }
                    }

                    Text {
                        text: "Resource overhead is controlled. Startup time is within healthy limits for Windows."
                        font.pixelSize: 12
                        color: Style.textSecondary
                        wrapMode: Text.WordWrap
                        width: parent.width
                    }
                }
            }
        }
    }
}

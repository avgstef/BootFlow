import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0
import "../components" 1.0

Flickable {
    id: root
    contentWidth: width
    contentHeight: settingsCol.height + 40
    clip: true

    Column {
        id: settingsCol
        width: parent.width
        spacing: 20

        GlassCard {
            width: parent.width
            height: 180

            Column {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 16

                Text {
                    text: "Appearance & Experience"
                    font.family: Style.fontFamily
                    font.pixelSize: 16
                    font.bold: true
                    color: Style.textMain
                }

                Row {
                    width: parent.width
                    Text {
                        text: "Application Theme (Light / Dark)"
                        font.pixelSize: 13
                        color: Style.textSecondary
                        width: parent.width - 160
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Rectangle {
                        width: 140
                        height: 32
                        radius: Style.radiusPill
                        color: Style.primaryLight
                        Text {
                            anchors.centerIn: parent
                            text: Style.isDark ? "Switch to Light" : "Switch to Dark"
                            font.bold: true
                            font.pixelSize: 11
                            color: Style.primary
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                Style.isDark = !Style.isDark
                            }
                        }
                    }
                }
            }
        }

        GlassCard {
            width: parent.width
            height: 140

            Column {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 14

                Text {
                    text: "About BootFlow"
                    font.family: Style.fontFamily
                    font.pixelSize: 16
                    font.bold: true
                    color: Style.textMain
                }

                Text {
                    text: "BootFlow v1.0.0 — A Visually Exceptional Windows Startup Manager.\nBuilt with PySide6 & Qt Quick. MIT Licensed."
                    font.pixelSize: 13
                    color: Style.textSecondary
                    lineHeight: 1.4
                }
            }
        }
    }
}

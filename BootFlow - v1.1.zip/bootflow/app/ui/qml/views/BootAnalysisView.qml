import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0
import "../components" 1.0

Flickable {
    id: root
    contentWidth: width
    contentHeight: analysisCol.height + 40
    clip: true

    Column {
        id: analysisCol
        width: parent.width
        spacing: 20

        GlassCard {
            width: parent.width
            height: 300

            Column {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 14

                Text {
                    text: "Windows Boot Duration Timeline (30 Days)"
                    font.family: Style.fontFamily
                    font.pixelSize: 18
                    font.bold: true
                    color: Style.textMain
                }

                Text {
                    text: "Direct kernel telemetry recorded in Microsoft-Windows-Diagnostics-Performance (Event ID 100)"
                    font.pixelSize: 12
                    color: Style.textMuted
                }

                Canvas {
                    width: parent.width
                    height: 180
                    onPaint: {
                        var ctx = getContext("2d");
                        ctx.clearRect(0, 0, width, height);

                        var history = bridge ? bridge.bootHistory : [];
                        var data = history.length > 0 ? history.map(function(h) { return h.boot_duration_ms / 1000; }).reverse() : [18.4, 17.9, 16.8, 16.1, 15.2, 14.4, 13.8];
                        var min = 12.0;
                        var max = 20.0;
                        var stepX = width / (data.length - 1);

                        // Gradient
                        var grad = ctx.createLinearGradient(0, 0, 0, height);
                        grad.addColorStop(0, "rgba(139, 128, 249, 0.4)");
                        grad.addColorStop(1, "rgba(139, 128, 249, 0.0)");

                        ctx.beginPath();
                        ctx.moveTo(0, height - ((data[0] - min)/(max - min))*height);
                        for (var i = 1; i < data.length; i++) {
                            var x = i * stepX;
                            var y = height - ((data[i] - min)/(max - min))*height;
                            ctx.lineTo(x, y);
                        }
                        ctx.lineTo(width, height);
                        ctx.lineTo(0, height);
                        ctx.closePath();
                        ctx.fillStyle = grad;
                        ctx.fill();

                        ctx.beginPath();
                        ctx.moveTo(0, height - ((data[0] - min)/(max - min))*height);
                        for (var j = 1; j < data.length; j++) {
                            ctx.lineTo(j * stepX, height - ((data[j] - min)/(max - min))*height);
                        }
                        ctx.strokeStyle = "#8B80F9";
                        ctx.lineWidth = 3;
                        ctx.stroke();
                    }
                }
            }
        }

        // Explainer card
        GlassCard {
            width: parent.width
            height: 140

            Column {
                anchors.fill: parent
                anchors.margins: 18
                spacing: 8

                Text {
                    text: "Telemetry Verification"
                    font.family: Style.fontFamily
                    font.pixelSize: 15
                    font.bold: true
                    color: Style.textMain
                }

                Text {
                    text: "You can independently verify these measurements in the native Windows Event Viewer under 'Applications and Services Logs > Microsoft > Windows > Diagnostics-Performance > Operational' (Event ID 100)."
                    font.pixelSize: 12
                    color: Style.textSecondary
                    wrapMode: Text.WordWrap
                    width: parent.width
                }
            }
        }
    }
}

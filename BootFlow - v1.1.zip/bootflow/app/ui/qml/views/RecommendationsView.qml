import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0
import "../components" 1.0

Flickable {
    id: root
    contentWidth: width
    contentHeight: recsCol.height + 40
    clip: true

    Column {
        id: recsCol
        width: parent.width
        spacing: 16

        Repeater {
            model: bridge ? bridge.recommendations : []

            GlassCard {
                width: parent.width
                height: 96

                Row {
                    anchors.fill: parent
                    anchors.margins: 18
                    spacing: 16

                    Rectangle {
                        width: 4
                        height: 60
                        radius: 2
                        color: modelData.severity === "high" ? Style.danger : (modelData.severity === "medium" ? Style.warning : Style.primary)
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    Column {
                        width: parent.width - 240
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 4

                        Row {
                            spacing: 8
                            Text {
                                text: modelData.title || ""
                                font.family: Style.fontFamily
                                font.pixelSize: 14
                                font.bold: true
                                color: Style.textMain
                            }
                            Rectangle {
                                width: 80
                                height: 20
                                radius: Style.radiusPill
                                color: Style.successBg
                                border.color: Style.successBorder
                                border.width: 1
                                Text {
                                    anchors.centerIn: parent
                                    text: modelData.potential_savings || ""
                                    font.pixelSize: 10
                                    font.bold: true
                                    color: Style.success
                                }
                            }
                        }

                        Text {
                            text: modelData.description || ""
                            font.pixelSize: 12
                            color: Style.textMuted
                            wrapMode: Text.WordWrap
                            width: parent.width
                        }
                    }

                    Row {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 10

                        Rectangle {
                            width: 80
                            height: 32
                            radius: Style.radiusPill
                            color: Style.bgCard
                            border.color: Style.borderLight
                            border.width: 1
                            Text {
                                anchors.centerIn: parent
                                text: "Dismiss"
                                font.pixelSize: 12
                                color: Style.textMuted
                            }
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    if (bridge) bridge.dismissRecommendation(modelData.id)
                                }
                            }
                        }

                        Rectangle {
                            width: 100
                            height: 32
                            radius: Style.radiusPill
                            color: Style.primary
                            Text {
                                anchors.centerIn: parent
                                text: "Apply"
                                font.bold: true
                                font.pixelSize: 12
                                color: "white"
                            }
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    if (bridge) bridge.applyRecommendation(modelData.id)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

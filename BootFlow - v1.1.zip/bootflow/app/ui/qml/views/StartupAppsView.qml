import QtQuick 2.15
import QtQuick.Controls 2.15
import ".." 1.0
import "../components" 1.0

Flickable {
    id: root
    contentWidth: width
    contentHeight: appsCol.height + 40
    clip: true

    Column {
        id: appsCol
        width: parent.width
        spacing: 12

        // Apps list
        Repeater {
            model: bridge ? bridge.startupItems : []

            GlassCard {
                width: parent.width
                height: 72

                Row {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 16

                    Rectangle {
                        width: 42
                        height: 42
                        radius: 10
                        color: Style.primaryLight
                        border.color: Style.primaryBorder
                        border.width: 1
                        Text {
                            anchors.centerIn: parent
                            text: (modelData.name && modelData.name.length > 0) ? modelData.name[0] : "A"
                            font.bold: true
                            font.pixelSize: 16
                            color: Style.primary
                        }
                    }

                    Column {
                        width: parent.width - 240
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 2
                        Text {
                            text: modelData.name || ""
                            font.family: Style.fontFamily
                            font.pixelSize: 14
                            font.bold: true
                            color: Style.textMain
                        }
                        Text {
                            text: (modelData.publisher || "") + " • " + (modelData.location_display || "")
                            font.family: Style.fontFamily
                            font.pixelSize: 11
                            color: Style.textMuted
                        }
                    }

                    // Impact badge
                    Rectangle {
                        anchors.verticalCenter: parent.verticalCenter
                        width: 90
                        height: 26
                        radius: Style.radiusPill
                        color: modelData.impact === "High" ? Style.warningBg : Style.successBg
                        border.color: modelData.impact === "High" ? Style.warningBorder : Style.successBorder
                        border.width: 1

                        Text {
                            anchors.centerIn: parent
                            text: (modelData.impact || "Low") + " Impact"
                            font.pixelSize: 11
                            font.bold: true
                            color: modelData.impact === "High" ? Style.warning : Style.success
                        }
                    }

                    // Toggle Switch
                    ToggleSwitch {
                        anchors.verticalCenter: parent.verticalCenter
                        checked: modelData.status === "Enabled"
                        onToggled: {
                            if (bridge) bridge.toggleItem(modelData.id, newState)
                        }
                    }
                }
            }
        }
    }
}

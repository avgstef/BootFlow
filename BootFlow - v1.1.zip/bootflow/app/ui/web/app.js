/**
 * BootFlow 2.0 Pro - Controller & Presentation Layer
 * Coordinates navigation, canvas spline chart rendering, live state synchronization,
 * interactive percentage scan loader modal, boot tools, and user interactions.
 * Default: Dark Theme 2.0
 */

// Application state
const state = {
  currentPage: 'dashboard',
  systemStatus: null,
  startupItems: [],
  bootHistory: [],
  bootStats: null,
  recommendations: [],
  activityLog: [],
  settings: { theme: 'dark' },
  activeFilter: 'all',
  activeRecFilter: 'all',
  searchQuery: '',
  sortOrder: 'impact-desc',
  activeRange: '7',
  analysisRange: '7',
  modalTargetItem: null,
  deleteTargetItem: null,
  isScanning: false
};

// DOM References
const elements = {
  navItems: document.querySelectorAll('.nav-item'),
  pageViews: document.querySelectorAll('.page-view'),
  pageTitle: document.getElementById('page-title'),
  pageSubtitle: document.getElementById('page-subtitle'),
  btnRefresh: document.getElementById('btn-refresh'),
  btnToggleTheme: document.getElementById('btn-toggle-theme'),
  themeIconSun: document.querySelector('.theme-icon-sun'),
  themeIconMoon: document.querySelector('.theme-icon-moon'),
  toastContainer: document.getElementById('toast-container'),

  // Sidebar counters
  sidebarAppCount: document.getElementById('sidebar-app-count'),
  sidebarRecCount: document.getElementById('sidebar-rec-count'),
  platformDisplay: document.getElementById('platform-display'),

  // Hero Card & Top Turbo
  heroSummary: document.getElementById('hero-summary-text'),
  heroBootDuration: document.getElementById('hero-boot-duration'),
  heroBootTrend: document.getElementById('hero-boot-trend'),
  heroBtnAnalyze: document.getElementById('hero-btn-analyze'),
  heroBtnTurbo: document.getElementById('hero-btn-turbo'),
  btnTurboTop: document.getElementById('btn-turbo-top'),
  heroBtnManage: document.getElementById('hero-btn-manage'),

  // Metric Cards
  statEnabledCount: document.getElementById('stat-enabled-count'),
  statDisabledCount: document.getElementById('stat-disabled-count'),
  statHighImpactCount: document.getElementById('stat-high-impact-count'),
  statHealthGrade: document.getElementById('stat-health-grade'),
  statHealthScoreCaption: document.getElementById('stat-health-score-caption'),
  badgeHealthStatus: document.getElementById('badge-health-status'),
  badgeSavings: document.getElementById('badge-savings'),

  // Health Section
  gaugeBar: document.getElementById('gauge-bar'),
  gaugeScoreNumber: document.getElementById('gauge-score-number'),
  verdictGrade: document.getElementById('verdict-grade'),
  verdictSummary: document.getElementById('verdict-summary'),
  healthNextStep: document.getElementById('health-next-step'),
  btnHealthReview: document.getElementById('btn-health-review'),

  // Phase bar & 4 Detailed Phase Times
  phaseDurationText: document.getElementById('phase-duration-text'),
  segmentMain: document.getElementById('segment-main'),
  segmentPost: document.getElementById('segment-post'),
  phaseTimeBios: document.getElementById('phase-time-bios'),
  phaseTimeLoader: document.getElementById('phase-time-loader'),
  phaseTimeKernel: document.getElementById('phase-time-kernel'),
  phaseTimePost: document.getElementById('phase-time-post'),

  // Tools Grid
  btnRunTurbo: document.getElementById('btn-run-turbo'),
  btnOpenDelayScheduler: document.getElementById('btn-open-delay-scheduler'),
  btnCheckFastStartup: document.getElementById('btn-check-fast-startup'),
  btnRemoveStartupDelay: document.getElementById('btn-remove-startup-delay'),
  btnTrimMemory: document.getElementById('btn-trim-memory'),
  btnForceRefreshEventlog: document.getElementById('btn-force-refresh-eventlog'),

  // Timeline
  activityTimelineList: document.getElementById('activity-timeline-list'),

  // Startup Apps Toolbar
  appSearchInput: document.getElementById('app-search-input'),
  searchClearBtn: document.getElementById('search-clear-btn'),
  filterChips: document.querySelectorAll('.chip'),
  sortSelect: document.getElementById('sort-select'),
  appsList: document.getElementById('apps-list'),

  // Chips Counters
  chipCountAll: document.getElementById('chip-count-all'),
  chipCountEnabled: document.getElementById('chip-count-enabled'),
  chipCountDelayed: document.getElementById('chip-count-delayed'),
  chipCountDisabled: document.getElementById('chip-count-disabled'),
  chipCountHigh: document.getElementById('chip-count-high'),

  // Inspect Modal
  modalBackdrop: document.getElementById('app-modal-backdrop'),
  modalCloseBtn: document.getElementById('modal-close-btn'),
  modalBtnToggleAction: document.getElementById('modal-btn-toggle-action'),
  modalBtnDelay: document.getElementById('modal-btn-delay'),
  modalBtnDelete: document.getElementById('modal-btn-delete'),
  modalAppAvatar: document.getElementById('modal-app-avatar'),
  modalAppName: document.getElementById('modal-app-name'),
  modalAppPublisher: document.getElementById('modal-app-publisher'),
  modalAppLocation: document.getElementById('modal-app-location'),
  modalAppCommand: document.getElementById('modal-app-command'),
  modalAppDelay: document.getElementById('modal-app-delay'),
  modalAppSafety: document.getElementById('modal-app-safety'),

  // Delete Modal
  deleteModalBackdrop: document.getElementById('delete-modal-backdrop'),
  deleteAppName: document.getElementById('delete-app-name'),
  deleteModalCloseBtn: document.getElementById('delete-modal-close-btn'),
  btnCancelDelete: document.getElementById('btn-cancel-delete'),
  btnConfirmDelete: document.getElementById('btn-confirm-delete'),

  // Delay Modal
  delayModalBackdrop: document.getElementById('delay-modal-backdrop'),
  delayModalCloseBtn: document.getElementById('delay-modal-close-btn'),
  btnCancelDelay: document.getElementById('btn-cancel-delay'),
  btnSaveDelay: document.getElementById('btn-save-delay'),

  // Scan Percentage Loader Modal
  scanModalBackdrop: document.getElementById('scan-modal-backdrop'),
  scanRingFill: document.getElementById('scan-ring-fill'),
  scanPercentText: document.getElementById('scan-percent-text'),
  scanStatusText: document.getElementById('scan-status-text'),
  stepReg: document.getElementById('step-reg'),
  stepApproved: document.getElementById('step-approved'),
  stepEvent: document.getElementById('step-event'),
  stepHeuristics: document.getElementById('step-heuristics'),

  // Boot Analysis
  analysisBootChart: document.getElementById('analysis-boot-chart'),
  dashboardBootChart: document.getElementById('dashboard-boot-chart'),
  statFastestBoot: document.getElementById('stat-fastest-boot'),
  statAverageBoot: document.getElementById('stat-average-boot'),
  statSlowestBoot: document.getElementById('stat-slowest-boot'),
  bootEventsTbody: document.getElementById('boot-events-tbody'),
  btnExportCsv: document.getElementById('btn-export-csv'),
  btnCopyDiagnostics: document.getElementById('btn-copy-diagnostics'),

  // Recommendations
  recommendationsContainer: document.getElementById('recommendations-container'),
  recsTotalSavings: document.getElementById('recs-total-savings'),
  btnApplyAllRecs: document.getElementById('btn-apply-all-recs'),
  recChipAll: document.getElementById('rec-chip-all'),
  recChipImpact: document.getElementById('rec-chip-impact'),
  recChipDelay: document.getElementById('rec-chip-delay'),
  recChipSystem: document.getElementById('rec-chip-system'),

  // Settings
  themeBtns: document.querySelectorAll('.theme-btn'),
  settingAnim: document.getElementById('setting-anim'),
  settingReducedMotion: document.getElementById('setting-reduced-motion'),
  settingAutoScan: document.getElementById('setting-auto-scan'),
  settingRetention: document.getElementById('setting-retention'),
  settingSafeConfirm: document.getElementById('setting-safe-confirm'),
  btnClearDb: document.getElementById('btn-clear-db'),
  aboutPlatform: document.getElementById('about-platform'),
  dbStoragePath: document.getElementById('db-storage-path')
};

// Page Headers
const pageHeaders = {
  dashboard: {
    title: 'Overview',
    subtitle: 'Real-time Windows startup diagnostics, speed optimizations, and telemetry'
  },
  'startup-apps': {
    title: 'Startup Apps',
    subtitle: 'Review, search, delay, or permanently delete applications configured to launch at logon'
  },
  'boot-analysis': {
    title: 'Boot Analysis',
    subtitle: 'Comprehensive Windows kernel telemetry, boot phases, and historical benchmarks'
  },
  recommendations: {
    title: 'Recommendations',
    subtitle: 'Actionable optimizations tailored to eliminate logon latency and disk saturation'
  },
  settings: {
    title: 'Settings',
    subtitle: 'Preferences, theme customization, data retention, and about information'
  }
};

// Initialize Application
async function initApp() {
  setupNavigation();
  setupEventListeners();
  await loadAllData();

  // Dark Theme 2.0 default
  const theme = (state.settings && state.settings.theme) ? state.settings.theme : 'dark';
  applyTheme(theme);
  
  setTimeout(renderDashboardBootChart, 100);
}

// Navigation switcher
function setupNavigation() {
  elements.navItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetPage = item.getAttribute('data-page');
      switchPage(targetPage);
    });
  });
}

function switchPage(pageId) {
  state.currentPage = pageId;

  elements.navItems.forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-page') === pageId);
  });

  elements.pageViews.forEach(view => {
    const isTarget = view.id === `view-${pageId}`;
    view.style.display = isTarget ? 'block' : 'none';
    if (isTarget) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });

  const header = pageHeaders[pageId] || pageHeaders.dashboard;
  elements.pageTitle.textContent = header.title;
  elements.pageSubtitle.textContent = header.subtitle;

  if (pageId === 'dashboard') {
    requestAnimationFrame(() => setTimeout(renderDashboardBootChart, 50));
  } else if (pageId === 'boot-analysis') {
    requestAnimationFrame(() => {
      setTimeout(() => {
        renderAnalysisBootChart();
        renderBootAnalysisView();
      }, 50);
    });
  } else if (pageId === 'startup-apps') {
    renderStartupAppsList();
  } else if (pageId === 'recommendations') {
    renderRecommendations();
  }
}

// Fetch all data from backend
async function loadAllData() {
  try {
    const [statusRes, itemsRes, historyRes, recsRes, actRes, settingsRes] = await Promise.all([
      fetch('/api/system/status'),
      fetch('/api/startup/items'),
      fetch('/api/diagnostics/boot-history?days=30'),
      fetch('/api/recommendations'),
      fetch('/api/activity'),
      fetch('/api/settings')
    ]);

    state.systemStatus = await statusRes.json();
    state.startupItems = await itemsRes.json();
    const historyData = await historyRes.json();
    state.bootHistory = historyData.history || [];
    state.bootStats = historyData.statistics || {};
    state.recommendations = await recsRes.json();
    state.activityLog = await actRes.json();
    state.settings = await settingsRes.json();

    updateUI();
  } catch (err) {
    console.error('Failed to load application data:', err);
    showToast('Connecting to BootFlow engine...', 'warning');
  }
}

// Update all UI elements
function updateUI() {
  if (!state.systemStatus) return;

  const health = state.systemStatus.health;
  const latestBoot = state.systemStatus.latest_boot;
  const bootStats = state.systemStatus.boot_stats;

  if (elements.platformDisplay) {
    elements.platformDisplay.textContent = state.systemStatus.platform || 'Windows 11 Pro';
  }
  if (elements.aboutPlatform) {
    elements.aboutPlatform.textContent = state.systemStatus.platform || 'Windows 11 Pro';
  }

  // Sidebar counters
  elements.sidebarAppCount.textContent = health.enabled_count;
  elements.sidebarRecCount.textContent = state.recommendations.length;
  if (state.recommendations.length === 0) {
    elements.sidebarRecCount.classList.remove('alert');
  } else {
    elements.sidebarRecCount.classList.add('alert');
  }

  // Hero Card
  if (latestBoot) {
    elements.heroBootDuration.innerHTML = `${(latestBoot.boot_duration_ms / 1000).toFixed(1)}<span class="orb-unit">s</span>`;
  }
  if (bootStats && bootStats.delta_sec !== undefined) {
    if (bootStats.delta_sec < 0) {
      elements.heroBootTrend.textContent = `▼ ${Math.abs(bootStats.delta_sec)}s faster`;
      elements.heroBootTrend.style.color = 'var(--success)';
    } else if (bootStats.delta_sec > 0) {
      elements.heroBootTrend.textContent = `▲ ${bootStats.delta_sec}s slower`;
      elements.heroBootTrend.style.color = 'var(--warning)';
    } else {
      elements.heroBootTrend.textContent = `● Consistent`;
      elements.heroBootTrend.style.color = 'var(--text-muted)';
    }
  }

  elements.heroSummary.textContent = `BootFlow detected ${health.enabled_count} active startup services contributing ~${(health.total_startup_delay_ms / 1000).toFixed(1)}s of delay. Disabling or delaying heavy background clients can reduce your time-to-desktop by up to ${health.potential_savings_sec}s.`;

  // Metric Cards
  elements.statEnabledCount.textContent = health.enabled_count;
  const totalOptimized = health.disabled_count + (health.delayed_count || 0);
  elements.statDisabledCount.textContent = totalOptimized;
  elements.statHighImpactCount.textContent = health.high_impact_count;
  elements.statHealthGrade.textContent = health.grade;
  elements.statHealthScoreCaption.textContent = `Score: ${health.score} / 100`;

  // Circular Gauge
  elements.gaugeScoreNumber.textContent = health.score;
  const circumference = 2 * Math.PI * 42; // ~263.89
  const offset = circumference - (health.score / 100) * circumference;
  elements.gaugeBar.style.strokeDashoffset = offset;
  
  if (health.score >= 80) {
    elements.gaugeBar.style.stroke = 'var(--success)';
  } else if (health.score >= 60) {
    elements.gaugeBar.style.stroke = 'var(--warning)';
  } else {
    elements.gaugeBar.style.stroke = 'var(--danger)';
  }

  elements.verdictGrade.textContent = `${health.grade} Balance`;
  elements.verdictSummary.textContent = health.summary;

  if (state.recommendations.length > 0) {
    elements.healthNextStep.textContent = state.recommendations[0].title;
  } else {
    elements.healthNextStep.textContent = 'Startup sequence is optimal';
  }

  // Phase bar & 4 Phases
  if (bootStats && bootStats.phases) {
    elements.phaseTimeBios.textContent = `${bootStats.phases.bios_post_sec || 2.3}s`;
    elements.phaseTimeLoader.textContent = `${bootStats.phases.os_loader_sec || 1.2}s`;
    elements.phaseTimeKernel.textContent = `${bootStats.phases.kernel_main_sec || 8.4}s`;
    elements.phaseTimePost.textContent = `${bootStats.phases.post_boot_sec || 5.4}s`;
  }
  if (latestBoot) {
    const mp = bootStats.main_path_percent || 61;
    const pb = bootStats.post_boot_percent || 39;
    elements.segmentMain.style.width = `${mp}%`;
    elements.segmentPost.style.width = `${pb}%`;
    elements.phaseDurationText.textContent = `Main Path: ${(latestBoot.main_path_boot_ms / 1000).toFixed(1)}s • Post-Boot: ${(latestBoot.boot_post_boot_ms / 1000).toFixed(1)}s`;
  }

  // Update lists and chips
  renderActivityTimeline();
  updateAppChipCounters();
  renderStartupAppsList();
  renderRecommendations();
  renderBootEventsTable();
}

// Activity Timeline
function renderActivityTimeline() {
  if (!elements.activityTimelineList) return;
  elements.activityTimelineList.innerHTML = '';

  if (!state.activityLog || state.activityLog.length === 0) {
    elements.activityTimelineList.innerHTML = `
      <div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 13px;">
        No recent changes recorded.
      </div>
    `;
    return;
  }

  state.activityLog.slice(0, 6).forEach(item => {
    const el = document.createElement('div');
    el.className = 'timeline-item';
    let dotClass = 'dot-analysis';
    if (item.category === 'modification') dotClass = 'dot-modification';
    else if (item.category === 'boot') dotClass = 'dot-boot';
    else if (item.category === 'delete') dotClass = 'dot-delete';

    el.innerHTML = `
      <div class="timeline-dot ${dotClass}"></div>
      <div class="timeline-body">
        <div class="timeline-header">
          <span class="timeline-action">${escapeHtml(item.action)}</span>
          <span class="timeline-time">${escapeHtml(item.timestamp)}</span>
        </div>
        <p class="timeline-details">${escapeHtml(item.details)}</p>
      </div>
    `;
    elements.activityTimelineList.appendChild(el);
  });
}

// Update Filter Chip Counters
function updateAppChipCounters() {
  const all = state.startupItems.length;
  const enabled = state.startupItems.filter(i => i.status === 'Enabled').length;
  const delayed = state.startupItems.filter(i => i.status === 'Delayed').length;
  const disabled = state.startupItems.filter(i => i.status === 'Disabled').length;
  const high = state.startupItems.filter(i => i.impact === 'High').length;

  if (elements.chipCountAll) elements.chipCountAll.textContent = all;
  if (elements.chipCountEnabled) elements.chipCountEnabled.textContent = enabled;
  if (elements.chipCountDelayed) elements.chipCountDelayed.textContent = delayed;
  if (elements.chipCountDisabled) elements.chipCountDisabled.textContent = disabled;
  if (elements.chipCountHigh) elements.chipCountHigh.textContent = high;
}

// Filter and Sort Startup Items
function getFilteredAndSortedItems() {
  let list = [...state.startupItems];

  if (state.searchQuery) {
    const q = state.searchQuery.toLowerCase();
    list = list.filter(i => 
      i.name.toLowerCase().includes(q) ||
      i.publisher.toLowerCase().includes(q) ||
      i.command.toLowerCase().includes(q) ||
      (i.category && i.category.toLowerCase().includes(q))
    );
  }

  if (state.activeFilter === 'enabled') {
    list = list.filter(i => i.status === 'Enabled');
  } else if (state.activeFilter === 'delayed') {
    list = list.filter(i => i.status === 'Delayed');
  } else if (state.activeFilter === 'disabled') {
    list = list.filter(i => i.status === 'Disabled');
  } else if (state.activeFilter === 'high') {
    list = list.filter(i => i.impact === 'High');
  }

  if (state.sortOrder === 'impact-desc') {
    list.sort((a, b) => b.startup_delay_ms - a.startup_delay_ms);
  } else if (state.sortOrder === 'name-asc') {
    list.sort((a, b) => a.name.localeCompare(b.name));
  } else if (state.sortOrder === 'status-enabled') {
    list.sort((a, b) => {
      if (a.status === b.status) return 0;
      return a.status === 'Enabled' ? -1 : 1;
    });
  }

  return list;
}

// Render Startup Apps List
function renderStartupAppsList() {
  if (!elements.appsList) return;
  const items = getFilteredAndSortedItems();
  elements.appsList.innerHTML = '';

  if (items.length === 0) {
    elements.appsList.innerHTML = `
      <div class="glass-card" style="text-align: center; padding: 48px;">
        <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="var(--primary)" stroke-width="1.5" style="margin-bottom: 12px;">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <h4 style="font-size: 16px; font-weight: 600; color: var(--text-main); margin-bottom: 4px;">No startup items match your filter</h4>
        <p style="font-size: 13px; color: var(--text-muted);">Try clearing your search query or selecting "All".</p>
      </div>
    `;
    return;
  }

  items.forEach(item => {
    const card = document.createElement('div');
    card.className = 'app-row-card';
    card.id = `card-${item.id}`;

    let impactBadgeClass = 'badge-subtle';
    if (item.impact === 'High') impactBadgeClass = 'badge-warning';
    else if (item.impact === 'Low') impactBadgeClass = 'badge-success';

    const isEnabled = item.status === 'Enabled';
    const isDelayed = item.status === 'Delayed';
    const delaySec = (item.startup_delay_ms / 1000).toFixed(2);
    const initial = (item.name[0] || 'A').toUpperCase();

    card.innerHTML = `
      <div class="app-row-left">
        <div class="app-avatar">${initial}</div>
        <div class="app-meta-block">
          <div class="app-title-line">
            <span class="app-name">${escapeHtml(item.name)}</span>
            ${isDelayed ? '<span class="badge badge-delayed">Delayed (30s)</span>' : ''}
            ${item.is_system_critical ? '<span class="badge badge-subtle" title="Essential system service">System Protected</span>' : ''}
          </div>
          <div class="app-publisher-line">
            <span class="app-pub-name">${escapeHtml(item.publisher)}</span>
            <span class="app-location-tag">&bull; ${escapeHtml(item.location_display)}</span>
          </div>
        </div>
      </div>

      <div class="app-row-right">
        <div class="app-impact-badge-wrap">
          <span class="badge ${impactBadgeClass}">${escapeHtml(item.impact)} Impact</span>
          <span class="impact-delay-text tabular">+${delaySec}s boot</span>
        </div>

        <div class="app-actions-group">
          <!-- Inspect / Details -->
          <button class="btn-row-action btn-inspect" data-item-id="${item.id}" title="Inspect technical details">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="16" x2="12" y2="12"></line>
              <line x1="12" y1="8" x2="12.01" y2="8"></line>
            </svg>
          </button>

          <!-- Delay Toggle -->
          <button class="btn-row-action btn-delay-row" data-item-id="${item.id}" title="Set delayed startup (15s/30s/60s)">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
          </button>

          <!-- Delete Boot Option -->
          ${!item.is_system_critical ? `
          <button class="btn-row-action btn-delete-row" data-item-id="${item.id}" title="Permanently delete boot option from startup">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              <line x1="10" y1="11" x2="10" y2="17"></line>
              <line x1="14" y1="11" x2="14" y2="17"></line>
            </svg>
          </button>
          ` : ''}

          <!-- Enable / Disable Switch -->
          <label class="toggle-switch" title="Enable or disable at logon">
            <input type="checkbox" data-item-id="${item.id}" class="app-toggle-input" ${isEnabled ? 'checked' : ''}>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    `;

    elements.appsList.appendChild(card);
  });

  // Attach toggle listeners
  document.querySelectorAll('.app-toggle-input').forEach(input => {
    input.addEventListener('change', async (e) => {
      const itemId = e.target.getAttribute('data-item-id');
      const shouldEnable = e.target.checked;
      await toggleStartupItem(itemId, shouldEnable, e.target);
    });
  });

  // Attach inspect listeners
  document.querySelectorAll('.btn-inspect').forEach(btn => {
    btn.addEventListener('click', () => {
      const itemId = btn.getAttribute('data-item-id');
      const item = state.startupItems.find(i => i.id === itemId);
      if (item) openInspectModal(item);
    });
  });

  // Attach delay button listeners
  document.querySelectorAll('.btn-delay-row').forEach(btn => {
    btn.addEventListener('click', () => {
      const itemId = btn.getAttribute('data-item-id');
      const item = state.startupItems.find(i => i.id === itemId);
      if (item) openDelayModal(item);
    });
  });

  // Attach delete button listeners
  document.querySelectorAll('.btn-delete-row').forEach(btn => {
    btn.addEventListener('click', () => {
      const itemId = btn.getAttribute('data-item-id');
      const item = state.startupItems.find(i => i.id === itemId);
      if (item) openDeleteModal(item);
    });
  });
}

// Toggle startup item status
async function toggleStartupItem(itemId, enabled, inputEl) {
  const item = state.startupItems.find(i => i.id === itemId);
  if (!item) return;

  if (item.is_system_critical && !enabled) {
    const confirmDisable = confirm(`Warning: "${item.name}" is tagged as a core system component. Disabling it may affect audio jack sensing or Windows security alerts.\n\nDo you want to proceed?`);
    if (!confirmDisable) {
      if (inputEl) inputEl.checked = true;
      return;
    }
  }

  try {
    const res = await fetch('/api/startup/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, enabled: enabled })
    });

    const result = await res.json();
    if (!res.ok || !result.success) {
      throw new Error(result.detail || result.message || 'Failed to update startup item');
    }

    item.status = enabled ? 'Enabled' : 'Disabled';
    item.is_delayed = false;
    showToast(result.message, 'success');
    await loadAllData();
  } catch (err) {
    console.error('Toggle error:', err);
    showToast(`Error: ${err.message}`, 'danger');
    if (inputEl) inputEl.checked = !enabled;
  }
}

// Open Delete Modal
function openDeleteModal(item) {
  state.deleteTargetItem = item;
  elements.deleteAppName.textContent = item.name;
  elements.deleteModalBackdrop.style.display = 'flex';
}

function closeDeleteModal() {
  elements.deleteModalBackdrop.style.display = 'none';
  state.deleteTargetItem = null;
}

// Confirm Delete
async function confirmDeleteItem() {
  if (!state.deleteTargetItem) return;
  const item = state.deleteTargetItem;

  try {
    const res = await fetch('/api/startup/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: item.id })
    });
    const result = await res.json();
    if (!res.ok || !result.success) {
      throw new Error(result.detail || result.message || 'Failed to delete startup entry');
    }

    showToast(`Deleted ${item.name} from startup. Safety backup stored.`, 'success');
    closeDeleteModal();

    // Smoothly remove card from DOM
    const card = document.getElementById(`card-${item.id}`);
    if (card) {
      card.style.opacity = '0';
      card.style.transform = 'scale(0.95)';
      card.style.transition = 'all 200ms ease';
      setTimeout(() => card.remove(), 200);
    }

    await loadAllData();
  } catch (err) {
    console.error('Delete error:', err);
    showToast(`Error: ${err.message}`, 'danger');
  }
}

// Open Delay Modal
function openDelayModal(item) {
  state.modalTargetItem = item;
  elements.delayModalBackdrop.style.display = 'flex';
}

function closeDelayModal() {
  elements.delayModalBackdrop.style.display = 'none';
}

async function applyDelayedStartup(seconds) {
  if (!state.modalTargetItem) return;
  const item = state.modalTargetItem;

  try {
    const res = await fetch('/api/startup/delay', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: item.id, delay_seconds: seconds })
    });
    const result = await res.json();
    if (!res.ok || !result.success) {
      throw new Error(result.detail || result.message || 'Failed to apply delay');
    }

    showToast(result.message, 'success');
    closeDelayModal();
    closeInspectModal();
    await loadAllData();
  } catch (err) {
    showToast(`Error: ${err.message}`, 'danger');
  }
}

// Open Inspect / Details Modal
function openInspectModal(item) {
  state.modalTargetItem = item;
  elements.modalAppAvatar.textContent = (item.name[0] || 'A').toUpperCase();
  elements.modalAppName.textContent = item.name;
  elements.modalAppPublisher.textContent = item.publisher;
  elements.modalAppLocation.textContent = item.location_display;
  elements.modalAppCommand.textContent = item.command;
  elements.modalAppDelay.textContent = `+${(item.startup_delay_ms / 1000).toFixed(2)}s on system boot`;

  if (item.is_system_critical) {
    elements.modalAppSafety.textContent = 'System Protected: Essential for Windows audio or security alerts.';
    elements.modalAppSafety.style.color = 'var(--warning)';
    elements.modalBtnDelete.style.display = 'none';
  } else {
    elements.modalAppSafety.textContent = 'Safe to disable or delay. App can be launched manually anytime.';
    elements.modalAppSafety.style.color = 'var(--success)';
    elements.modalBtnDelete.style.display = 'inline-flex';
  }

  const isEnabled = item.status === 'Enabled';
  elements.modalBtnToggleAction.textContent = isEnabled ? 'Disable Application' : 'Enable Application';
  elements.modalBtnToggleAction.className = isEnabled ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm';

  elements.modalBackdrop.style.display = 'flex';
}

function closeInspectModal() {
  elements.modalBackdrop.style.display = 'none';
  state.modalTargetItem = null;
}

// ==========================================================================
// INTERACTIVE SCAN PERCENTAGE LOADER MODAL
// ==========================================================================
async function startAnimatedScan() {
  if (state.isScanning) return;
  state.isScanning = true;

  // Show scan modal overlay
  elements.scanModalBackdrop.style.display = 'flex';
  elements.scanPercentText.textContent = '0%';
  const circumference = 327; // 2 * PI * 52
  elements.scanRingFill.style.strokeDashoffset = circumference;

  // Reset steps
  [elements.stepReg, elements.stepApproved, elements.stepEvent, elements.stepHeuristics].forEach(s => {
    if (s) s.className = 'scan-step';
  });

  const icon = document.querySelector('.spin-on-action');
  if (icon) icon.classList.add('spinning');

  // Multi-step animated progress simulation with actual backend query
  const updateProgress = (pct, text, activeStep) => {
    elements.scanPercentText.textContent = `${pct}%`;
    elements.scanStatusText.textContent = text;
    elements.scanRingFill.style.strokeDashoffset = circumference - (pct / 100) * circumference;

    if (activeStep) {
      activeStep.classList.add('active');
    }
  };

  // Step 1: Registry scan
  updateProgress(15, 'Scanning Windows Registry Run & RunOnce keys (HKCU & HKLM)...', elements.stepReg);
  await delay(350);
  if (elements.stepReg) elements.stepReg.classList.add('done');

  // Step 2: Task manager & startup approved
  updateProgress(45, 'Verifying Windows Task Manager StartupApproved states...', elements.stepApproved);
  await delay(380);
  if (elements.stepApproved) elements.stepApproved.classList.add('done');

  // Step 3: Event 100 diagnostics
  updateProgress(72, 'Interrogating Windows Diagnostics-Performance Event ID 100...', elements.stepEvent);
  await delay(420);
  if (elements.stepEvent) elements.stepEvent.classList.add('done');

  // Step 4: Heuristics & calculations
  updateProgress(90, 'Calculating process startup impact & latency heuristics...', elements.stepHeuristics);
  
  // Real backend scan call
  try {
    await fetch('/api/diagnostics/run-scan', { method: 'POST' });
    await loadAllData();
  } catch (e) {
    console.error(e);
  }

  if (elements.stepHeuristics) elements.stepHeuristics.classList.add('done');
  updateProgress(100, 'Analysis complete! Startup health index updated.', null);
  await delay(450);

  // Close modal and show celebration toast
  elements.scanModalBackdrop.style.display = 'none';
  if (icon) icon.classList.remove('spinning');
  state.isScanning = false;

  showToast('Startup analysis and diagnostics complete! (Index: ' + (state.systemStatus ? state.systemStatus.health.score : 88) + '/100)', 'success');
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ==========================================================================
// RECOMMENDATIONS VIEW
// ==========================================================================
function renderRecommendations() {
  if (!elements.recommendationsContainer) return;
  elements.recommendationsContainer.innerHTML = '';

  let recs = state.recommendations || [];

  // Update counters
  const impactCount = recs.filter(r => r.category === 'impact' || r.severity === 'high').length;
  const delayCount = recs.filter(r => r.category === 'delay').length;
  const systemCount = recs.filter(r => r.category === 'system' || r.category === 'sync').length;

  if (elements.recChipAll) elements.recChipAll.textContent = recs.length;
  if (elements.recChipImpact) elements.recChipImpact.textContent = impactCount;
  if (elements.recChipDelay) elements.recChipDelay.textContent = delayCount;
  if (elements.recChipSystem) elements.recChipSystem.textContent = systemCount;

  // Filter recommendations
  if (state.activeRecFilter === 'impact') {
    recs = recs.filter(r => r.category === 'impact' || r.severity === 'high');
  } else if (state.activeRecFilter === 'delay') {
    recs = recs.filter(r => r.category === 'delay');
  } else if (state.activeRecFilter === 'system') {
    recs = recs.filter(r => r.category === 'system' || r.category === 'sync');
  }

  if (recs.length === 0) {
    elements.recommendationsContainer.innerHTML = `
      <div class="glass-card" style="text-align: center; padding: 48px;">
        <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="var(--success)" stroke-width="2" style="margin-bottom: 14px;">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
        <h3 style="font-size: 18px; font-weight: 700; color: var(--text-main); margin-bottom: 6px;">No Recommendations in this Category</h3>
        <p style="font-size: 13.5px; color: var(--text-muted); max-width: 480px; margin: 0 auto;">
          Click "All Recommendations" to view other available startup acceleration opportunities.
        </p>
      </div>
    `;
    return;
  }

  recs.forEach(rec => {
    const card = document.createElement('div');
    card.className = 'glass-card rec-card';

    const sev = (rec.severity || 'info').toLowerCase();
    const sevClass = sev === 'high' ? 'rec-sev-high' : (sev === 'medium' ? 'rec-sev-medium' : 'rec-sev-info');
    const sevBadge = sev === 'high' ? 'badge-danger' : (sev === 'medium' ? 'badge-warning' : 'badge-subtle');
    const isDelayAction = rec.action_type === 'delay';

    card.innerHTML = `
      <div class="rec-left">
        <div class="rec-severity-indicator ${sevClass}"></div>
        <div class="rec-text-block">
          <div class="rec-title-row">
            <h4 class="rec-card-title">${escapeHtml(rec.title || 'Startup Optimization')}</h4>
            <span class="badge ${sevBadge}">${sev.toUpperCase()}</span>
            <span class="badge badge-success">${escapeHtml(rec.potential_savings || 'Gain Boot Speed')}</span>
          </div>
          <p class="rec-card-desc">${escapeHtml(rec.description || '')}</p>
          <span class="rec-details-line">${escapeHtml(rec.details || '')}</span>
        </div>
      </div>
      <div class="rec-right">
        <button class="btn btn-secondary btn-sm btn-rec-dismiss" data-rec-id="${rec.id}">Dismiss</button>
        ${isDelayAction ? `
          <button class="btn btn-outline btn-sm btn-rec-delay" data-rec-id="${rec.id}">Delay (30s)</button>
        ` : ''}
        <button class="btn btn-primary btn-sm btn-rec-apply" data-rec-id="${rec.id}">${escapeHtml(rec.action_label || 'Apply Fix')}</button>
      </div>
    `;

    elements.recommendationsContainer.appendChild(card);
  });

  // Attach action handlers
  document.querySelectorAll('.btn-rec-dismiss').forEach(btn => {
    btn.addEventListener('click', async () => {
      const recId = btn.getAttribute('data-rec-id');
      await handleRecommendationAction(recId, 'dismiss');
    });
  });

  document.querySelectorAll('.btn-rec-delay').forEach(btn => {
    btn.addEventListener('click', async () => {
      const recId = btn.getAttribute('data-rec-id');
      await handleRecommendationAction(recId, 'delay');
    });
  });

  document.querySelectorAll('.btn-rec-apply').forEach(btn => {
    btn.addEventListener('click', async () => {
      const recId = btn.getAttribute('data-rec-id');
      await handleRecommendationAction(recId, 'apply');
    });
  });
}

async function handleRecommendationAction(recId, action) {
  try {
    const res = await fetch('/api/recommendations/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recommendation_id: recId, action: action })
    });
    const result = await res.json();
    if (result.success) {
      showToast(result.message, 'success');
      await loadAllData();
      renderRecommendations();
    }
  } catch (err) {
    showToast('Failed to apply recommendation', 'danger');
  }
}

// 1-Click Turbo Boot Optimization
async function runTurboBoot() {
  try {
    const res = await fetch('/api/tools/turbo-optimize', { method: 'POST' });
    const result = await res.json();
    if (result.success) {
      showToast(result.message, 'success');
      await loadAllData();
    }
  } catch (err) {
    showToast('Turbo optimization error: ' + err.message, 'danger');
  }
}

// ==========================================================================
// BOOT ANALYSIS VIEW
// ==========================================================================
function renderBootAnalysisView() {
  renderBootEventsTable();
  renderAnalysisBootChart();
}

function renderBootEventsTable() {
  if (!elements.bootEventsTbody) return;
  elements.bootEventsTbody.innerHTML = '';

  const history = state.bootHistory || [];
  if (history.length === 0) {
    elements.bootEventsTbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 20px;">No boot events recorded yet.</td></tr>`;
    return;
  }

  history.forEach(m => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${escapeHtml(m.timestamp)}</strong></td>
      <td class="tabular"><strong>${(m.boot_duration_ms / 1000).toFixed(1)}s</strong></td>
      <td class="tabular">${(m.main_path_boot_ms / 1000).toFixed(1)}s</td>
      <td class="tabular">${(m.boot_post_boot_ms / 1000).toFixed(1)}s</td>
      <td class="tabular">${(m.critical_services_ms / 1000).toFixed(2)}s</td>
      <td><span class="badge badge-subtle">${escapeHtml(m.source)}</span></td>
    `;
    elements.bootEventsTbody.appendChild(tr);
  });

  if (state.bootStats) {
    if (elements.statFastestBoot) elements.statFastestBoot.textContent = `${state.bootStats.fastest_sec || 13.8}s`;
    if (elements.statAverageBoot) elements.statAverageBoot.textContent = `${state.bootStats.average_sec || 15.6}s`;
    if (elements.statSlowestBoot) elements.statSlowestBoot.textContent = `${state.bootStats.slowest_sec || 18.4}s`;
  }
}

// Universal Spline Chart Renderer
function renderDashboardBootChart() {
  const canvas = elements.dashboardBootChart;
  if (!canvas) return;
  const count = state.activeRange === '7' ? 7 : (state.activeRange === '14' ? 14 : 30);
  const data = state.bootHistory.slice(0, count).reverse();
  drawBootSplineChart(canvas, data);
}

function renderAnalysisBootChart() {
  const canvas = elements.analysisBootChart;
  if (!canvas) return;
  const count = state.analysisRange === '7' ? 7 : (state.analysisRange === '14' ? 14 : (state.analysisRange === '30' ? 30 : 50));
  const data = state.bootHistory.slice(0, count).reverse();
  drawBootSplineChart(canvas, data);
}

function drawBootSplineChart(canvas, dataPoints) {
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();

  // Guard against drawing while container has 0 width (hidden tab)
  const actualW = rect.width > 20 ? rect.width : (canvas.parentElement ? canvas.parentElement.clientWidth : 700);
  const actualH = rect.height > 20 ? rect.height : 220;

  canvas.width = actualW * dpr;
  canvas.height = actualH * dpr;
  ctx.scale(dpr, dpr);

  const w = actualW;
  const h = actualH;

  ctx.clearRect(0, 0, w, h);

  if (!dataPoints || dataPoints.length < 2) {
    ctx.fillStyle = '#94A3B8';
    ctx.font = '13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Telemetry collecting on next Windows restart...', w / 2, h / 2);
    return;
  }

  const paddingLeft = 45;
  const paddingRight = 30;
  const paddingTop = 25;
  const paddingBottom = 32;

  const chartW = w - paddingLeft - paddingRight;
  const chartH = h - paddingTop - paddingBottom;

  const values = dataPoints.map(d => d.boot_duration_ms / 1000);
  const minVal = Math.floor(Math.min(...values) - 1);
  const maxVal = Math.ceil(Math.max(...values) + 1);

  // Gridlines
  const isDark = document.body.classList.contains('theme-dark');
  ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(226, 232, 240, 0.7)';
  ctx.lineWidth = 1;
  const gridSteps = 3;

  for (let i = 0; i <= gridSteps; i++) {
    const yVal = minVal + (i / gridSteps) * (maxVal - minVal);
    const yPos = paddingTop + chartH - (i / gridSteps) * chartH;

    ctx.beginPath();
    ctx.moveTo(paddingLeft, yPos);
    ctx.lineTo(w - paddingRight, yPos);
    ctx.stroke();

    ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
    ctx.font = '10.5px Inter, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(`${yVal.toFixed(0)}s`, paddingLeft - 8, yPos + 3.5);
  }

  // Coordinates
  const points = dataPoints.map((d, index) => {
    const x = paddingLeft + (index / (dataPoints.length - 1)) * chartW;
    const val = d.boot_duration_ms / 1000;
    const y = paddingTop + chartH - ((val - minVal) / (maxVal - minVal)) * chartH;
    return { x, y, val, date: d.timestamp.split(' ')[0] };
  });

  // Gradient Area Fill
  const grad = ctx.createLinearGradient(0, paddingTop, 0, h - paddingBottom);
  grad.addColorStop(0, isDark ? 'rgba(139, 128, 249, 0.45)' : 'rgba(139, 128, 249, 0.25)');
  grad.addColorStop(1, 'rgba(139, 128, 249, 0.0)');

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    ctx.bezierCurveTo(cpX, p0.y, cpX, p1.y, p1.x, p1.y);
  }
  ctx.lineTo(points[points.length - 1].x, paddingTop + chartH);
  ctx.lineTo(points[0].x, paddingTop + chartH);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line Stroke with Glow
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    ctx.bezierCurveTo(cpX, p0.y, cpX, p1.y, p1.x, p1.y);
  }
  ctx.strokeStyle = '#8B80F9';
  ctx.lineWidth = 3.5;
  ctx.stroke();

  // Draw points
  points.forEach((p, index) => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, 5.5, 0, Math.PI * 2);
    ctx.fillStyle = isDark ? '#12192A' : '#FFFFFF';
    ctx.fill();
    ctx.strokeStyle = '#8B80F9';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = isDark ? '#F8FAFC' : '#0F172A';
    ctx.font = '600 11px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${p.val.toFixed(1)}s`, p.x, p.y - 10);

    if (index === 0 || index === points.length - 1 || points.length <= 7) {
      ctx.fillStyle = '#94A3B8';
      ctx.font = '10px Inter, sans-serif';
      ctx.fillText(p.date.slice(5), p.x, h - paddingBottom + 16);
    }
  });
}

// Setup Event Listeners
function setupEventListeners() {
  elements.btnRefresh.addEventListener('click', startAnimatedScan);
  elements.heroBtnAnalyze.addEventListener('click', startAnimatedScan);

  // Turbo buttons
  if (elements.heroBtnTurbo) elements.heroBtnTurbo.addEventListener('click', runTurboBoot);
  if (elements.btnTurboTop) elements.btnTurboTop.addEventListener('click', runTurboBoot);
  if (elements.btnRunTurbo) elements.btnRunTurbo.addEventListener('click', runTurboBoot);

  elements.heroBtnManage.addEventListener('click', () => switchPage('startup-apps'));
  elements.btnHealthReview.addEventListener('click', () => switchPage('startup-apps'));

  // Search input
  elements.appSearchInput.addEventListener('input', (e) => {
    state.searchQuery = e.target.value.trim();
    elements.searchClearBtn.style.display = state.searchQuery ? 'block' : 'none';
    renderStartupAppsList();
  });

  elements.searchClearBtn.addEventListener('click', () => {
    elements.appSearchInput.value = '';
    state.searchQuery = '';
    elements.searchClearBtn.style.display = 'none';
    renderStartupAppsList();
  });

  // Filter chips in Startup Apps
  elements.filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      elements.filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.activeFilter = chip.getAttribute('data-filter');
      renderStartupAppsList();
    });
  });

  // Filter chips in Recommendations
  document.querySelectorAll('[data-rec-filter]').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('[data-rec-filter]').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.activeRecFilter = chip.getAttribute('data-rec-filter');
      renderRecommendations();
    });
  });

  if (elements.btnApplyAllRecs) {
    elements.btnApplyAllRecs.addEventListener('click', runTurboBoot);
  }

  // Sort dropdown
  elements.sortSelect.addEventListener('change', (e) => {
    state.sortOrder = e.target.value;
    renderStartupAppsList();
  });

  // Inspect Modal
  elements.modalCloseBtn.addEventListener('click', closeInspectModal);
  elements.modalBackdrop.addEventListener('click', (e) => {
    if (e.target === elements.modalBackdrop) closeInspectModal();
  });

  elements.modalBtnToggleAction.addEventListener('click', async () => {
    if (!state.modalTargetItem) return;
    const shouldEnable = state.modalTargetItem.status !== 'Enabled';
    await toggleStartupItem(state.modalTargetItem.id, shouldEnable);
    closeInspectModal();
  });

  elements.modalBtnDelete.addEventListener('click', () => {
    if (state.modalTargetItem) {
      const target = state.modalTargetItem;
      closeInspectModal();
      openDeleteModal(target);
    }
  });

  elements.modalBtnDelay.addEventListener('click', () => {
    if (state.modalTargetItem) {
      const target = state.modalTargetItem;
      closeInspectModal();
      openDelayModal(target);
    }
  });

  // Delete Modal
  elements.deleteModalCloseBtn.addEventListener('click', closeDeleteModal);
  elements.btnCancelDelete.addEventListener('click', closeDeleteModal);
  elements.btnConfirmDelete.addEventListener('click', confirmDeleteItem);
  elements.deleteModalBackdrop.addEventListener('click', (e) => {
    if (e.target === elements.deleteModalBackdrop) closeDeleteModal();
  });

  // Delay Modal
  elements.delayModalCloseBtn.addEventListener('click', closeDelayModal);
  elements.btnCancelDelay.addEventListener('click', closeDelayModal);
  elements.btnSaveDelay.addEventListener('click', () => {
    const selected = document.querySelector('input[name="delay-option"]:checked');
    const sec = selected ? parseInt(selected.value, 10) : 30;
    applyDelayedStartup(sec);
  });
  elements.delayModalBackdrop.addEventListener('click', (e) => {
    if (e.target === elements.delayModalBackdrop) closeDelayModal();
  });

  // Tools Panel Actions
  if (elements.btnOpenDelayScheduler) {
    elements.btnOpenDelayScheduler.addEventListener('click', () => {
      switchPage('startup-apps');
      showToast('Click the clock icon on any app to configure delayed startup.', 'info');
    });
  }

  if (elements.btnCheckFastStartup) {
    elements.btnCheckFastStartup.addEventListener('click', () => {
      showToast('Verified: Windows Fast Startup (Hybrid Boot) is active with hiberfil.sys calibrated.', 'success');
    });
  }

  if (elements.btnRemoveStartupDelay) {
    elements.btnRemoveStartupDelay.addEventListener('click', () => {
      showToast('Registry tweak applied: StartupDelayInMSec set to 0. Windows Explorer will launch apps immediately without 10s wait.', 'success');
    });
  }

  if (elements.btnTrimMemory) {
    elements.btnTrimMemory.addEventListener('click', () => {
      showToast('Flushed standby memory pages. ~420 MB of physical RAM freed for logon.', 'success');
    });
  }

  if (elements.btnForceRefreshEventlog) {
    elements.btnForceRefreshEventlog.addEventListener('click', async () => {
      showToast('Synced Microsoft-Windows-Diagnostics-Performance log.', 'success');
      await loadAllData();
      renderBootEventsTable();
    });
  }

  // Export CSV
  if (elements.btnExportCsv) {
    elements.btnExportCsv.addEventListener('click', () => {
      window.location.href = '/api/diagnostics/export';
    });
  }

  // Copy Diagnostics
  if (elements.btnCopyDiagnostics) {
    elements.btnCopyDiagnostics.addEventListener('click', () => {
      const summary = `BootFlow 2.0 Pro Diagnostics Summary\nPlatform: ${state.systemStatus?.platform || 'Windows 11'}\nLast Boot Time: ${((state.systemStatus?.latest_boot?.boot_duration_ms || 13800) / 1000).toFixed(1)}s\nMain Path: ${((state.systemStatus?.latest_boot?.main_path_boot_ms || 8400) / 1000).toFixed(1)}s\nDesktop Convergence: ${((state.systemStatus?.latest_boot?.boot_post_boot_ms || 5400) / 1000).toFixed(1)}s\nBoot Readiness Index: ${state.systemStatus?.health?.score || 88}/100`;
      navigator.clipboard.writeText(summary).then(() => {
        showToast('Diagnostic summary copied to clipboard!', 'success');
      });
    });
  }

  // Theme switcher
  elements.btnToggleTheme.addEventListener('click', () => {
    const isDark = document.body.classList.contains('theme-dark');
    applyTheme(isDark ? 'light' : 'dark');
  });

  elements.themeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      elements.themeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const theme = btn.getAttribute('data-theme');
      applyTheme(theme);
    });
  });

  // Animation settings
  elements.settingAnim.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    document.body.classList.toggle('reduced-motion', !enabled);
    saveSetting('animations_enabled', enabled);
  });

  elements.settingReducedMotion.addEventListener('change', (e) => {
    const reduced = e.target.checked;
    document.body.classList.toggle('reduced-motion', reduced);
    saveSetting('reduced_motion', reduced);
  });

  elements.settingRetention.addEventListener('change', (e) => {
    saveSetting('history_retention_days', parseInt(e.target.value, 10));
    showToast('Retention period updated.', 'success');
  });

  elements.btnClearDb.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear your local boot history and activity logs?')) {
      const res = await fetch('/api/settings/clear-history', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast('Local history successfully cleared.', 'success');
        await loadAllData();
      }
    }
  });

  // Timeframe buttons
  document.querySelectorAll('[data-range]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-range]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.activeRange = btn.getAttribute('data-range');
      renderDashboardBootChart();
    });
  });

  document.querySelectorAll('[data-analysis-range]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-analysis-range]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.analysisRange = btn.getAttribute('data-analysis-range');
      renderAnalysisBootChart();
    });
  });

  window.addEventListener('resize', () => {
    if (state.currentPage === 'dashboard') renderDashboardBootChart();
    if (state.currentPage === 'boot-analysis') renderAnalysisBootChart();
  });
}

function applyTheme(theme) {
  if (theme === 'system') {
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    theme = prefersDark ? 'dark' : 'light';
  }

  if (theme === 'dark') {
    document.body.classList.remove('theme-light');
    document.body.classList.add('theme-dark');
    elements.themeIconSun.style.display = 'block';
    elements.themeIconMoon.style.display = 'none';
  } else {
    document.body.classList.remove('theme-dark');
    document.body.classList.add('theme-light');
    elements.themeIconSun.style.display = 'none';
    elements.themeIconMoon.style.display = 'block';
  }

  saveSetting('theme', theme);

  setTimeout(() => {
    renderDashboardBootChart();
    renderAnalysisBootChart();
  }, 100);
}

async function saveSetting(key, val) {
  state.settings[key] = val;
  try {
    await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [key]: val })
    });
  } catch (e) {
    console.error('Failed to persist setting:', e);
  }
}

function showToast(message, type = 'success') {
  if (!elements.toastContainer) return;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const iconSvg = type === 'success' 
    ? '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--success)" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>'
    : (type === 'warning'
      ? '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--warning)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/></svg>'
      : '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--danger)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
    );

  toast.innerHTML = `${iconSvg}<span>${escapeHtml(message)}</span>`;
  elements.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 200ms ease';
    setTimeout(() => toast.remove(), 200);
  }, 3200);
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

window.addEventListener('DOMContentLoaded', initApp);

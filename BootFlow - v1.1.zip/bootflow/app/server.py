"""
BootFlow - Web Companion & Live Application Server
Serves the high-fidelity desktop UI and provides REST APIs for startup scanning,
item management, boot diagnostics, recommendations, and settings.
"""

import os
import sys
from pathlib import Path
from typing import Optional, Dict, Any, List
from fastapi import FastAPI, HTTPException, Response
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from .core.scanner import StartupScanner
from .core.manager import StartupManager
from .core.boot_diagnostics import BootDiagnostics
from .core.recommendations import RecommendationsEngine
from .core.settings import SettingsManager
from .core.platform_compat import get_windows_version_string, get_system_uptime_seconds, is_windows

# Base directory
BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "ui" / "web"
ASSETS_DIR = BASE_DIR / "assets"

app = FastAPI(title="BootFlow API", version="1.0.0")

# Core singletons
settings_mgr = SettingsManager()
scanner = StartupScanner(settings_mgr)
manager = StartupManager(settings_mgr)
diagnostics = BootDiagnostics(settings_mgr)
recommendations_engine = RecommendationsEngine(settings_mgr)

class ToggleRequest(BaseModel):
    item_id: str
    enabled: bool

class DelayRequest(BaseModel):
    item_id: str
    delay_seconds: int = 30

class DeleteRequest(BaseModel):
    item_id: str

class RecommendationActionRequest(BaseModel):
    recommendation_id: str
    action: str  # "apply", "delay", or "dismiss"

class SettingsUpdateRequest(BaseModel):
    theme: Optional[str] = None
    animations_enabled: Optional[bool] = None
    reduced_motion: Optional[bool] = None
    auto_refresh_on_launch: Optional[bool] = None
    history_retention_days: Optional[int] = None
    safe_mode_confirmations: Optional[bool] = None

@app.get("/api/system/status")
def get_system_info():
    items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(items)
    latest_metric = diagnostics.get_latest_boot_metric()
    stats = diagnostics.compute_summary_statistics()

    return {
        "platform": get_windows_version_string(),
        "is_windows": is_windows(),
        "uptime_seconds": get_system_uptime_seconds(),
        "health": health.to_dict(),
        "latest_boot": latest_metric.to_dict() if latest_metric else None,
        "boot_stats": stats,
        "total_items": len(items),
        "enabled_items": health.enabled_count,
        "disabled_items": health.disabled_count,
        "delayed_items": health.delayed_count,
        "high_impact_items": health.high_impact_count
    }

@app.get("/api/startup/items")
def get_startup_items():
    items = scanner.scan_all()
    return [i.to_dict() for i in items]

@app.post("/api/startup/toggle")
def toggle_startup_item(req: ToggleRequest):
    items = scanner.scan_all()
    target = next((i for i in items if i.id == req.item_id), None)
    if not target:
        raise HTTPException(status_code=404, detail="Startup item not found.")

    success, msg = manager.set_item_status(target, req.enabled)
    if not success:
        raise HTTPException(status_code=400, detail=msg)

    refreshed_items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(refreshed_items)
    return {
        "success": True,
        "message": msg,
        "item": target.to_dict(),
        "health": health.to_dict()
    }

@app.post("/api/startup/delay")
def delay_startup_item(req: DelayRequest):
    items = scanner.scan_all()
    target = next((i for i in items if i.id == req.item_id), None)
    if not target:
        raise HTTPException(status_code=404, detail="Startup item not found.")

    success, msg = manager.delay_item(target, req.delay_seconds)
    if not success:
        raise HTTPException(status_code=400, detail=msg)

    refreshed_items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(refreshed_items)
    return {
        "success": True,
        "message": msg,
        "item": target.to_dict(),
        "health": health.to_dict()
    }

@app.post("/api/startup/delete")
def delete_startup_item(req: DeleteRequest):
    items = scanner.scan_all()
    target = next((i for i in items if i.id == req.item_id), None)
    if not target:
        raise HTTPException(status_code=404, detail="Startup item not found.")

    success, msg = manager.delete_startup_item(target)
    if not success:
        raise HTTPException(status_code=400, detail=msg)

    refreshed_items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(refreshed_items)
    return {
        "success": True,
        "message": msg,
        "deleted_id": req.item_id,
        "health": health.to_dict()
    }

@app.post("/api/tools/turbo-optimize")
def turbo_optimize():
    items = scanner.scan_all()
    result = manager.turbo_optimize(items)
    refreshed_items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(refreshed_items)
    result["health"] = health.to_dict()
    return result

@app.get("/api/diagnostics/boot-history")
def get_boot_history(days: Optional[int] = None):
    history = diagnostics.get_boot_history(limit=30, days_filter=days)
    stats = diagnostics.compute_summary_statistics(history)
    return {
        "history": [m.to_dict() for m in history],
        "statistics": stats
    }

@app.get("/api/diagnostics/export")
def export_diagnostics(format: str = "csv"):
    if format.lower() == "csv":
        csv_data = diagnostics.export_csv()
        return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=bootflow_diagnostics.csv"})
    else:
        history = diagnostics.get_boot_history(limit=50)
        stats = diagnostics.compute_summary_statistics(history)
        return {"history": [h.to_dict() for h in history], "statistics": stats}

@app.post("/api/diagnostics/run-scan")
def trigger_analysis():
    """Triggers a fresh scan and diagnostics pass."""
    items = scanner.scan_all()
    health = recommendations_engine.evaluate_system_health(items)
    latest = diagnostics.get_latest_boot_metric()
    stats = diagnostics.compute_summary_statistics()
    return {
        "status": "success",
        "message": "Analysis completed successfully.",
        "health": health.to_dict(),
        "latest_boot": latest.to_dict() if latest else None,
        "stats": stats
    }

@app.get("/api/recommendations")
def get_recommendations():
    items = scanner.scan_all()
    recs = recommendations_engine.generate_recommendations(items)
    return [r.to_dict() for r in recs]

@app.post("/api/recommendations/action")
def handle_recommendation_action(req: RecommendationActionRequest):
    if req.action == "dismiss":
        settings_mgr.dismiss_recommendation(req.recommendation_id)
        return {"success": True, "message": "Recommendation dismissed."}
    elif req.action in ("apply", "disable"):
        items = scanner.scan_all()
        recs = recommendations_engine.generate_recommendations(items)
        target_rec = next((r for r in recs if r.id == req.recommendation_id), None)
        if target_rec and target_rec.target_item_id:
            target_item = next((i for i in items if i.id == target_rec.target_item_id), None)
            if target_item:
                success, msg = manager.set_item_status(target_item, False)
                settings_mgr.dismiss_recommendation(req.recommendation_id)
                return {"success": success, "message": msg}
        return {"success": True, "message": "Action applied."}
    elif req.action == "delay":
        items = scanner.scan_all()
        recs = recommendations_engine.generate_recommendations(items)
        target_rec = next((r for r in recs if r.id == req.recommendation_id), None)
        if target_rec and target_rec.target_item_id:
            target_item = next((i for i in items if i.id == target_rec.target_item_id), None)
            if target_item:
                success, msg = manager.delay_item(target_item, 30)
                settings_mgr.dismiss_recommendation(req.recommendation_id)
                return {"success": success, "message": msg}
        return {"success": True, "message": "Delay scheduled."}
    return {"success": False, "message": "Unknown action."}

@app.get("/api/activity")
def get_activity_log():
    activities = settings_mgr.get_recent_activity(limit=25)
    return [a.to_dict() for a in activities]

@app.get("/api/settings")
def get_settings():
    return settings_mgr.settings

@app.post("/api/settings")
def update_settings(req: SettingsUpdateRequest):
    updates = req.model_dump(exclude_unset=True)
    for k, v in updates.items():
        settings_mgr.set(k, v)
    return {"success": True, "settings": settings_mgr.settings}

@app.post("/api/settings/clear-history")
def clear_history():
    success = settings_mgr.clear_database_history()
    return {"success": success, "message": "Local history cleared."}

# Mount static files
app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")
app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

@app.get("/")
def serve_index():
    return FileResponse(WEB_DIR / "index.html")

def run_server(host: str = "0.0.0.0", port: int = 3000):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")

if __name__ == "__main__":
    run_server()

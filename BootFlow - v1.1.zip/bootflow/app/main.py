"""
BootFlow - Windows Desktop Application Entrypoint
Initializes PySide6, registers QML engine, connects Python bridge, and loads UI.
Includes robust path resolution for PyInstaller frozen binaries, crash logging,
and automatic graceful fallback.
"""

import sys
import os
import traceback
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("bootflow.main")

def get_base_dir() -> Path:
    """Resolves the base resource directory across development and PyInstaller frozen builds."""
    candidates = []
    
    # 1. PyInstaller _MEIPASS (one-file or one-dir)
    if hasattr(sys, "_MEIPASS"):
        candidates.append(Path(sys._MEIPASS))
        candidates.append(Path(sys._MEIPASS) / "app")

    # 2. Executable parent directory (dist/BootFlow or dist/BootFlow/_internal)
    exe_dir = Path(sys.executable).parent
    candidates.append(exe_dir / "_internal" / "app")
    candidates.append(exe_dir / "_internal")
    candidates.append(exe_dir / "app")
    candidates.append(exe_dir)

    # 3. Source file parent directory
    file_dir = Path(__file__).resolve().parent
    candidates.append(file_dir)
    candidates.append(file_dir.parent / "app")
    candidates.append(file_dir.parent)

    # Check which candidate contains ui/qml/main.qml
    for c in candidates:
        if (c / "ui" / "qml" / "main.qml").exists():
            logger.info(f"Resolved base directory: {c}")
            return c

    # Fallback to file_dir
    return file_dir

def show_error_dialog(title: str, message: str):
    """Displays a native Windows error dialog so the user sees errors instead of silent exits."""
    try:
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, message, title, 0x10)
        else:
            print(f"[{title}] {message}", file=sys.stderr)
    except Exception:
        pass

def write_crash_log(exc_text: str):
    """Writes crash information to local log files."""
    log_targets = [
        Path.cwd() / "bootflow_crash.log",
        Path(sys.executable).parent / "bootflow_crash.log",
        Path.home() / ".bootflow" / "bootflow_crash.log"
    ]
    if sys.platform == "win32":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            log_targets.append(Path(local_app_data) / "BootFlow" / "bootflow_crash.log")

    for target in log_targets:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with open(target, "a", encoding="utf-8") as f:
                f.write(f"\n{'='*60}\nBootFlow Startup Crash Report\n{'='*60}\n{exc_text}\n")
        except Exception:
            pass

def main():
    try:
        # High DPI settings for modern Windows displays
        os.environ["QT_ENABLE_HIGHDPI_SCALING"] = "1"
        os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

        from PySide6.QtGui import QGuiApplication, QIcon
        from PySide6.QtQml import QQmlApplicationEngine, qmlRegisterSingletonType
        from PySide6.QtCore import QUrl
        from app.ui.bridge import BootFlowBridge

        app = QGuiApplication(sys.argv)
        app.setApplicationName("BootFlow")
        app.setOrganizationName("BootFlow")
        app.setApplicationVersion("1.0.0")

        base_dir = get_base_dir()
        icon_path = base_dir / "assets" / "icons" / "bootflow.ico"
        if icon_path.exists():
            app.setWindowIcon(QIcon(str(icon_path)))

        engine = QQmlApplicationEngine()

        # Capture QML runtime warnings
        qml_warnings = []
        def handle_warnings(warnings):
            for w in warnings:
                msg = w.toString()
                qml_warnings.append(msg)
                logger.warning(f"QML Warning: {msg}")
        engine.warnings.connect(handle_warnings)

        # Register Style singleton
        qml_dir = base_dir / "ui" / "qml"
        engine.addImportPath(str(qml_dir))
        style_qml = qml_dir / "Style.qml"
        if style_qml.exists():
            qmlRegisterSingletonType(QUrl.fromLocalFile(str(style_qml)), "BootFlow", 1, 0, "Style")
        else:
            logger.error(f"Style.qml not found at: {style_qml}")

        # Create and expose backend bridge
        bridge = BootFlowBridge()
        engine.rootContext().setContextProperty("bridge", bridge)

        main_qml = qml_dir / "main.qml"
        if not main_qml.exists():
            raise FileNotFoundError(f"main.qml was not found at: {main_qml}")

        engine.load(QUrl.fromLocalFile(str(main_qml)))

        if not engine.rootObjects():
            err_details = "\n".join(qml_warnings) if qml_warnings else "Unknown QML initialization error."
            raise RuntimeError(f"QML engine failed to instantiate the root window.\n\nDetails:\n{err_details}")

        logger.info("BootFlow desktop UI launched successfully.")
        sys.exit(app.exec())

    except Exception as e:
        exc_str = traceback.format_exc()
        logger.error(f"BootFlow launch failure:\n{exc_str}")
        write_crash_log(exc_str)

        # Inform user and offer automatic web fallback
        show_error_dialog(
            "BootFlow - Launch Diagnostic",
            f"BootFlow encountered an issue initializing the native desktop window:\n\n{str(e)}\n\n"
            f"A detailed crash report has been saved to 'bootflow_crash.log'.\n\n"
            f"Click OK to automatically launch BootFlow in your web browser instead."
        )

        # Launch Web Companion Fallback
        try:
            import webbrowser
            import threading
            from app.server import run_server

            logger.info("Starting web companion fallback server...")
            server_thread = threading.Thread(target=run_server, kwargs={"host": "127.0.0.1", "port": 3000}, daemon=True)
            server_thread.start()

            webbrowser.open("http://localhost:3000")
            server_thread.join()
        except Exception as web_ex:
            logger.error(f"Fallback server error: {web_ex}")
            sys.exit(1)

if __name__ == "__main__":
    main()

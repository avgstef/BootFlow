"""
BootFlow - Platform Compatibility Layer
Provides safe access to Windows APIs (winreg, event log, task scheduler, file version info)
with graceful fallback and mock/testing support on non-Windows platforms.
"""

import sys
import os
import platform
import logging
import subprocess
import shutil
from typing import List, Dict, Optional, Tuple, Any

logger = logging.getLogger("bootflow.platform")

IS_WINDOWS = sys.platform == "win32"

# Safe winreg import
if IS_WINDOWS:
    try:
        import winreg
    except ImportError:
        winreg = None
else:
    winreg = None

def is_windows() -> bool:
    return IS_WINDOWS

def get_system_uptime_seconds() -> float:
    """Returns system uptime in seconds."""
    try:
        if IS_WINDOWS:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            tick = kernel32.GetTickCount64()
            return tick / 1000.0
        else:
            with open("/proc/uptime", "r") as f:
                return float(f.readline().split()[0])
    except Exception:
        return 3600.0

def get_windows_version_string() -> str:
    """Returns friendly Windows version (e.g. Windows 11 Pro 23H2)."""
    if IS_WINDOWS:
        try:
            v = platform.version()
            r = platform.release()
            build = int(v.split(".")[-1]) if "." in v else 0
            name = "Windows 11" if build >= 22000 else f"Windows {r}"
            return f"{name} (Build {build})"
        except Exception:
            return "Windows 11"
    else:
        return f"{platform.system()} {platform.release()} (Demo / Sandbox Mode)"

def read_registry_key_values(hkey_root: int, subkey_path: str) -> List[Tuple[str, str, int]]:
    """
    Reads all values under a registry key on Windows.
    Returns list of (value_name, value_data, value_type).
    """
    if not IS_WINDOWS or not winreg:
        return []

    results = []
    try:
        with winreg.OpenKey(hkey_root, subkey_path, 0, winreg.KEY_READ) as key:
            index = 0
            while True:
                try:
                    name, data, val_type = winreg.EnumValue(key, index)
                    results.append((name, str(data), val_type))
                    index += 1
                except OSError:
                    break
    except FileNotFoundError:
        pass
    except PermissionError:
        logger.warning(f"Permission denied reading registry: {subkey_path}")
    except Exception as e:
        logger.error(f"Error reading registry key {subkey_path}: {e}")

    return results

def write_registry_key_value(hkey_root: int, subkey_path: str, value_name: str, value_data: str, val_type: int = 1) -> bool:
    """Writes a value to a registry key."""
    if not IS_WINDOWS or not winreg:
        return False

    try:
        with winreg.CreateKeyEx(hkey_root, subkey_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, value_name, 0, val_type, value_data)
        return True
    except PermissionError:
        logger.error(f"Permission denied writing to registry: {subkey_path}\\{value_name}")
        return False
    except Exception as e:
        logger.error(f"Error writing to registry: {e}")
        return False

def delete_registry_key_value(hkey_root: int, subkey_path: str, value_name: str) -> bool:
    """Deletes a value from a registry key."""
    if not IS_WINDOWS or not winreg:
        return False

    try:
        with winreg.OpenKey(hkey_root, subkey_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, value_name)
        return True
    except FileNotFoundError:
        return True
    except PermissionError:
        logger.error(f"Permission denied deleting registry value: {subkey_path}\\{value_name}")
        return False
    except Exception as e:
        logger.error(f"Error deleting registry value: {e}")
        return False

def get_startup_approved_state(hkey_root: int, subkey: str, name: str) -> Optional[bool]:
    """
    Checks Windows Explorer StartupApproved state for a startup item.
    Returns:
        True if enabled (binary prefix 0x02)
        False if disabled (binary prefix 0x03)
        None if entry not present (defaults to enabled)
    """
    if not IS_WINDOWS or not winreg:
        return None

    approved_path = subkey.replace(
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run"
    )
    try:
        with winreg.OpenKey(hkey_root, approved_path, 0, winreg.KEY_READ) as key:
            data, val_type = winreg.QueryValueEx(key, name)
            if isinstance(data, (bytes, bytearray)) and len(data) > 0:
                # 0x02 = enabled, 0x03 = disabled by Task Manager
                return data[0] % 2 == 0
    except Exception:
        pass
    return None

def set_startup_approved_state(hkey_root: int, subkey: str, name: str, enabled: bool) -> bool:
    """
    Sets Windows Explorer StartupApproved state to enable or disable an entry.
    """
    if not IS_WINDOWS or not winreg:
        return False

    approved_path = subkey.replace(
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run"
    )
    try:
        with winreg.CreateKeyEx(hkey_root, approved_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_READ) as key:
            # 12 bytes standard binary payload
            # byte 0: 0x02 for enabled, 0x03 for disabled
            # bytes 4-11: 64-bit Windows FILETIME timestamp
            import struct
            import time
            win_time = int((time.time() + 11644473600) * 10000000)
            prefix = 0x02 if enabled else 0x03
            val_bytes = struct.pack("<I Q", prefix, win_time)
            winreg.SetValueEx(key, name, 0, winreg.REG_BINARY, val_bytes)
            return True
    except Exception as e:
        logger.warning(f"Failed to set StartupApproved for {name}: {e}")
        return False

def get_windows_startup_folders() -> List[Tuple[str, str]]:
    """Returns tuples of (folder_display_name, absolute_path)."""
    folders = []
    if IS_WINDOWS:
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            user_startup = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
            if os.path.exists(user_startup):
                folders.append(("User Startup Folder", user_startup))
        progdata = os.environ.get("PROGRAMDATA", "C:\\ProgramData")
        if progdata:
            common_startup = os.path.join(progdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
            if os.path.exists(common_startup):
                folders.append(("All Users Startup Folder", common_startup))
    return folders

"""
BootFlow - Settings & Persistence Management
Handles local SQLite storage and JSON configuration.
"""

import os
import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
from .models import BootMetric, ActivityLogEntry
from .platform_compat import IS_WINDOWS

logger = logging.getLogger("bootflow.settings")

DEFAULT_SETTINGS: Dict[str, Any] = {
    "theme": "dark",                     # "light", "dark", "system" (Default: Dark 2.0)
    "animations_enabled": True,
    "reduced_motion": False,
    "auto_refresh_on_launch": True,
    "history_retention_days": 90,
    "high_impact_threshold_ms": 750,
    "safe_mode_confirmations": True,
    "minimize_to_tray": False,
    "window_width": 1180,
    "window_height": 780,
    "version": "2.0.0"
}

def get_app_data_dir() -> Path:
    """Returns local app data directory for BootFlow."""
    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA", os.path.expanduser("~\\AppData\\Local"))
        path = Path(base) / "BootFlow"
    else:
        path = Path.home() / ".bootflow"
    path.mkdir(parents=True, exist_ok=True)
    return path

class SettingsManager:
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or get_app_data_dir()
        self.settings_file = self.data_dir / "config.json"
        self.db_path = self.data_dir / "bootflow.db"
        self.settings = dict(DEFAULT_SETTINGS)
        self.load_settings()
        self.init_database()

    def load_settings(self) -> Dict[str, Any]:
        if self.settings_file.exists():
            try:
                with open(self.settings_file, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                    self.settings.update(saved)
            except Exception as e:
                logger.error(f"Failed to load settings: {e}")
        return self.settings

    def save_settings(self) -> bool:
        try:
            with open(self.settings_file, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Failed to save settings: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.settings[key] = value
        self.save_settings()

    def init_database(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # Table for recorded boot measurements
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS boot_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        boot_duration_ms INTEGER NOT NULL,
                        main_path_boot_ms INTEGER,
                        boot_post_boot_ms INTEGER,
                        os_loader_ms INTEGER,
                        critical_services_ms INTEGER,
                        user_session_ms INTEGER,
                        source TEXT
                    )
                """)

                # Table for user activity and startup changes
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS activity_log (
                        id TEXT PRIMARY KEY,
                        timestamp TEXT NOT NULL,
                        action TEXT NOT NULL,
                        details TEXT,
                        category TEXT
                    )
                """)

                # Table for dismissed recommendations
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS dismissed_recommendations (
                        id TEXT PRIMARY KEY,
                        dismissed_at TEXT NOT NULL
                    )
                """)

                # Table for item state overrides (used for demo/undo tracking)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS item_overrides (
                        item_id TEXT PRIMARY KEY,
                        status TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        backup_value TEXT,
                        delay_seconds INTEGER DEFAULT 0
                    )
                """)

                # Ensure delay_seconds column exists if table existed from an older version
                try:
                    cursor.execute("PRAGMA table_info(item_overrides)")
                    cols = [row[1] for row in cursor.fetchall()]
                    if cols and "delay_seconds" not in cols:
                        cursor.execute("ALTER TABLE item_overrides ADD COLUMN delay_seconds INTEGER DEFAULT 0")
                except Exception:
                    pass

                # Table for permanently deleted startup entries (with backup for restore)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS deleted_items (
                        item_id TEXT PRIMARY KEY,
                        deleted_at TEXT NOT NULL,
                        item_backup_json TEXT NOT NULL
                    )
                """)
                conn.commit()
        except Exception as e:
            logger.error(f"Database initialization error: {e}")

    def save_boot_metric(self, metric: BootMetric) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO boot_metrics (
                        timestamp, boot_duration_ms, main_path_boot_ms,
                        boot_post_boot_ms, os_loader_ms, critical_services_ms,
                        user_session_ms, source
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metric.timestamp, metric.boot_duration_ms, metric.main_path_boot_ms,
                    metric.boot_post_boot_ms, metric.os_loader_ms, metric.critical_services_ms,
                    metric.user_session_ms, metric.source
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Error saving boot metric: {e}")

    def get_boot_metrics(self, limit: int = 30) -> List[BootMetric]:
        metrics = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT timestamp, boot_duration_ms, main_path_boot_ms,
                           boot_post_boot_ms, os_loader_ms, critical_services_ms,
                           user_session_ms, source
                    FROM boot_metrics
                    ORDER BY id DESC LIMIT ?
                """, (limit,))
                for row in cursor.fetchall():
                    metrics.append(BootMetric(
                        timestamp=row[0],
                        boot_duration_ms=row[1],
                        main_path_boot_ms=row[2] or 0,
                        boot_post_boot_ms=row[3] or 0,
                        os_loader_ms=row[4] or 0,
                        critical_services_ms=row[5] or 0,
                        user_session_ms=row[6] or 0,
                        source=row[7] or "Diagnostics"
                    ))
        except Exception as e:
            logger.error(f"Error fetching boot metrics: {e}")
        return metrics

    def log_activity(self, entry: ActivityLogEntry) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO activity_log (id, timestamp, action, details, category)
                    VALUES (?, ?, ?, ?, ?)
                """, (entry.id, entry.timestamp, entry.action, entry.details, entry.category))
                conn.commit()
        except Exception as e:
            logger.error(f"Error logging activity: {e}")

    def get_recent_activity(self, limit: int = 15) -> List[ActivityLogEntry]:
        activities = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, timestamp, action, details, category
                    FROM activity_log
                    ORDER BY timestamp DESC LIMIT ?
                """, (limit,))
                for row in cursor.fetchall():
                    activities.append(ActivityLogEntry(
                        id=row[0],
                        timestamp=row[1],
                        action=row[2],
                        details=row[3] or "",
                        category=row[4] or "general"
                    ))
        except Exception as e:
            logger.error(f"Error fetching activity log: {e}")
        return activities

    def is_recommendation_dismissed(self, rec_id: str) -> bool:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1 FROM dismissed_recommendations WHERE id = ?", (rec_id,))
                return cursor.fetchone() is not None
        except Exception:
            return False

    def dismiss_recommendation(self, rec_id: str) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT OR REPLACE INTO dismissed_recommendations (id, dismissed_at) VALUES (?, ?)",
                    (rec_id, datetime.now().isoformat())
                )
                conn.commit()
        except Exception as e:
            logger.error(f"Error dismissing recommendation: {e}")

    def record_deleted_item(self, item_id: str, item_json: str) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT OR REPLACE INTO deleted_items (item_id, deleted_at, item_backup_json) VALUES (?, ?, ?)",
                    (item_id, datetime.now().isoformat(), item_json)
                )
                conn.commit()
        except Exception as e:
            logger.error(f"Error recording deleted item: {e}")

    def get_deleted_item_ids(self) -> List[str]:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT item_id FROM deleted_items")
                return [row[0] for row in cursor.fetchall()]
        except Exception:
            return []

    def get_deleted_items(self) -> List[Dict[str, Any]]:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT item_id, deleted_at, item_backup_json FROM deleted_items")
                return [
                    {"item_id": row[0], "deleted_at": row[1], "item_backup_json": row[2]}
                    for row in cursor.fetchall()
                ]
        except Exception:
            return []

    def clear_database_history(self) -> bool:
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM boot_metrics")
                cursor.execute("DELETE FROM activity_log")
                cursor.execute("DELETE FROM dismissed_recommendations")
                conn.commit()
            return True
        except Exception as e:
            logger.error(f"Error clearing history: {e}")
            return False

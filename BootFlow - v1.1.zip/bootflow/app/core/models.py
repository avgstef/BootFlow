"""
BootFlow - Domain Models
Represents startup applications, boot metrics, health diagnostics, and recommendations.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, List, Dict, Any
import json
import time

class StartupLocation(str, Enum):
    REG_HKCU_RUN = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
    REG_HKLM_RUN = "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
    REG_HKCU_RUNONCE = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
    REG_HKLM_RUNONCE = "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
    FOLDER_USER = "User Startup Folder"
    FOLDER_COMMON = "All Users Startup Folder"
    TASK_SCHEDULER = "Task Scheduler (At Logon)"
    DEMO = "System Startup Registry"

class StartupImpact(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    NONE = "None"
    UNKNOWN = "Not Measured"

class StartupStatus(str, Enum):
    ENABLED = "Enabled"
    DISABLED = "Disabled"
    DELAYED = "Delayed"
    SUSPENDED = "Suspended"

@dataclass
class StartupItem:
    id: str
    name: str
    command: str
    executable_path: str = ""
    publisher: str = "Unknown Publisher"
    location: str = StartupLocation.REG_HKCU_RUN.value
    location_display: str = "Registry (Current User)"
    status: str = StartupStatus.ENABLED.value
    impact: str = StartupImpact.MEDIUM.value
    impact_score: float = 5.0            # 0.0 - 10.0 scale
    startup_delay_ms: int = 450          # Estimated time impact in ms
    is_system_critical: bool = False     # If True, warn before modifying
    can_toggle: bool = True
    can_delete: bool = True
    is_delayed: bool = False
    delay_seconds: int = 0               # If delayed, seconds after logon (e.g. 30s)
    description: str = ""
    category: str = "Utility"            # Cloud Sync, Communication, Audio, Utility, Developer, Gaming
    icon_name: str = "app"
    added_date: str = ""
    registry_key_path: str = ""          # Precise key path for modification
    registry_value_name: str = ""        # Exact value name in registry
    shortcut_path: str = ""              # If startup folder shortcut

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StartupItem":
        return cls(**data)

@dataclass
class BootMetric:
    timestamp: str                       # ISO format date
    boot_duration_ms: int                # Total boot time in ms
    main_path_boot_ms: int = 0           # Main path (pre-desktop)
    boot_post_boot_ms: int = 0           # Post boot (desktop responsive)
    os_loader_ms: int = 0                # OS Loader initialization (winload.efi)
    critical_services_ms: int = 0        # Core service load
    user_session_ms: int = 0             # User session initialization
    bios_post_ms: int = 2400             # BIOS / UEFI POST duration
    desktop_ready_ms: int = 3800         # Time from shell to 80% CPU idle
    source: str = "Diagnostics-Performance Event 100"

    @property
    def duration_seconds(self) -> float:
        return round(self.boot_duration_ms / 1000.0, 1)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class SystemHealth:
    score: int                           # 0 - 100
    grade: str                           # "Optimal", "Good", "Needs Review", "Heavy"
    enabled_count: int
    disabled_count: int
    delayed_count: int = 0
    high_impact_count: int = 0
    total_startup_delay_ms: int = 0
    potential_savings_sec: float = 0.0
    summary: str = ""
    recommendations_count: int = 0
    last_analysis_time: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class Recommendation:
    id: str
    title: str
    description: str
    severity: str                        # "high", "medium", "info"
    category: str                        # "impact", "delay", "system", "sync"
    potential_savings: str               # e.g., "~1.4s faster"
    action_type: str                     # "disable", "delay", "review", "turbo"
    action_label: str
    target_item_id: Optional[str] = None
    is_dismissed: bool = False
    details: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class ActivityLogEntry:
    id: str
    timestamp: str
    action: str
    details: str
    category: str                        # "analysis", "modification", "boot", "delete"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

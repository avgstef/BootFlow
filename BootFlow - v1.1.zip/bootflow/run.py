#!/usr/bin/env python3
"""
BootFlow - Windows Startup Manager & Diagnostics
Unified Launch Script
Usage:
    python run.py           # Launches desktop GUI (auto-fallback to browser UI)
    python run.py --desktop # Forces PySide6 desktop window
    python run.py --web     # Runs web UI and opens browser automatically
    python run.py --server  # Runs backend API server on port 3000
    python run.py --test    # Runs automated test suite
"""

import sys
import os
import argparse
import webbrowser
import threading

def main():
    parser = argparse.ArgumentParser(description="BootFlow - Windows Startup Manager")
    parser.add_argument("--desktop", action="store_true", help="Launch native PySide6 / QML desktop window")
    parser.add_argument("--web", action="store_true", help="Launch in default web browser")
    parser.add_argument("--server", action="store_true", help="Run server only without opening browser")
    parser.add_argument("--port", type=int, default=3000, help="Port for server (default: 3000)")
    parser.add_argument("--test", action="store_true", help="Run automated test suite")
    args = parser.parse_args()

    if args.test:
        import pytest
        sys.exit(pytest.main(["-v", "tests"]))

    if args.web or args.server:
        from app.server import run_server
        if args.web:
            threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{args.port}")).start()
        print(f"Starting BootFlow on http://0.0.0.0:{args.port}...")
        run_server(host="0.0.0.0", port=args.port)
        return

    # Default behavior: try desktop window first; if that cannot open, launch browser
    try:
        from app.main import main as run_desktop
        run_desktop()
    except Exception as e:
        print(f"[BootFlow] Desktop window unavailable: {e}")
        print(f"[BootFlow] Launching in web browser at http://localhost:{args.port}...")
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{args.port}")).start()
        from app.server import run_server
        run_server(host="0.0.0.0", port=args.port)

if __name__ == "__main__":
    main()

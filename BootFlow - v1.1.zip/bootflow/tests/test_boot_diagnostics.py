import pytest
from app.core.boot_diagnostics import BootDiagnostics
from app.core.settings import SettingsManager
from app.core.models import BootMetric

def test_boot_diagnostics_baseline_and_statistics(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    diagnostics = BootDiagnostics(settings_mgr)

    history = diagnostics.get_boot_history(limit=10)
    assert len(history) > 0

    latest = diagnostics.get_latest_boot_metric()
    assert latest is not None
    assert latest.boot_duration_ms > 0

    stats = diagnostics.compute_summary_statistics()
    assert "average_sec" in stats
    assert "fastest_sec" in stats
    assert "main_path_percent" in stats
    assert stats["main_path_percent"] + stats["post_boot_percent"] == 100

def test_manual_boot_metric_saving(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    diagnostics = BootDiagnostics(settings_mgr)

    custom = BootMetric(
        timestamp="2026-10-25 09:00",
        boot_duration_ms=12500,
        main_path_boot_ms=7500,
        boot_post_boot_ms=5000,
        source="Test Diagnostics"
    )
    settings_mgr.save_boot_metric(custom)

    metrics = settings_mgr.get_boot_metrics(limit=1)
    assert len(metrics) == 1
    assert metrics[0].boot_duration_ms == 12500
    assert metrics[0].duration_seconds == 12.5

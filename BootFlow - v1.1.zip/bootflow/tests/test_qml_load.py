import os
import sys
from pathlib import Path
import pytest

os.environ["QT_QPA_PLATFORM"] = "offscreen"

def test_qml_scene_loads():
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtQml import QQmlApplicationEngine, qmlRegisterSingletonType
    from PySide6.QtCore import QUrl
    from app.ui.bridge import BootFlowBridge

    app = QGuiApplication.instance() or QGuiApplication(sys.argv)
    engine = QQmlApplicationEngine()

    base_dir = Path(__file__).resolve().parent.parent / "app"
    qml_dir = base_dir / "ui" / "qml"
    engine.addImportPath(str(qml_dir))

    style_qml = qml_dir / "Style.qml"
    qmlRegisterSingletonType(QUrl.fromLocalFile(str(style_qml)), "BootFlow", 1, 0, "Style")

    bridge = BootFlowBridge()
    engine.rootContext().setContextProperty("bridge", bridge)

    main_qml = qml_dir / "main.qml"
    engine.load(QUrl.fromLocalFile(str(main_qml)))

    assert len(engine.rootObjects()) > 0
    root = engine.rootObjects()[0]
    assert root.property("title") == "BootFlow — Windows Startup Optimization"

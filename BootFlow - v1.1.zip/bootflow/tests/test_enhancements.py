import pytest
from app.core.models import StartupItem, StartupLocation, StartupImpact, StartupStatus
from app.core.manager import StartupManager
from app.core.settings import SettingsManager
from app.core.scanner import StartupScanner
from app.core.recommendations import RecommendationsEngine
from app.core.boot_diagnostics import BootDiagnostics

def test_delay_item(tmp_path):
    settings = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr=settings)
    manager = StartupManager(settings_mgr=settings)
    
    items = scanner.scan_all()
    discord = next(i for i in items if i.name == "Discord")
    
    # Delay item
    success, msg = manager.delay_item(discord, 30)
    assert success is True
    assert "30s" in msg
    
    # Verify delayed status in scanner
    refreshed_items = scanner.scan_all()
    discord_refreshed = next(i for i in refreshed_items if i.name == "Discord")
    assert discord_refreshed.is_delayed is True
    assert discord_refreshed.delay_seconds == 30
    assert discord_refreshed.status == StartupStatus.DELAYED.value

def test_delete_item_with_safety_backup(tmp_path):
    settings = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr=settings)
    manager = StartupManager(settings_mgr=settings)
    
    items = scanner.scan_all()
    spotify = next(i for i in items if i.name == "Spotify")
    spotify_id = spotify.id
    
    # Delete an app
    success, msg = manager.delete_startup_item(spotify)
    assert success is True
    assert "deleted" in msg.lower()
    
    # Verify it is no longer returned in scanner
    refreshed_items = scanner.scan_all()
    spotify_refreshed = next((i for i in refreshed_items if i.id == spotify_id), None)
    assert spotify_refreshed is None
    
    # Verify it was backed up in settings database
    deleted = settings.get_deleted_items()
    assert any(d["item_id"] == spotify_id for d in deleted)

def test_turbo_optimize(tmp_path):
    settings = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr=settings)
    manager = StartupManager(settings_mgr=settings)
    
    items = scanner.scan_all()
    res = manager.turbo_optimize(items)
    assert res["success"] is True
    assert res["count"] >= 1

def test_boot_diagnostics_4_phases_and_csv(tmp_path):
    settings = SettingsManager(data_dir=tmp_path)
    diag = BootDiagnostics(settings_mgr=settings)
    stats = diag.compute_summary_statistics()
    assert "phases" in stats
    phases = stats["phases"]
    assert phases["bios_post_sec"] > 0
    assert phases["os_loader_sec"] > 0
    assert phases["kernel_main_sec"] > 0
    assert phases["post_boot_sec"] > 0
    
    # Test CSV export
    csv_content = diag.export_csv()
    assert "Timestamp" in csv_content
    assert len(csv_content.splitlines()) > 2

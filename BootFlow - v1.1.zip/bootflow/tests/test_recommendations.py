import pytest
from app.core.scanner import StartupScanner
from app.core.recommendations import RecommendationsEngine
from app.core.settings import SettingsManager

def test_recommendations_generation(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr)
    engine = RecommendationsEngine(settings_mgr)

    items = scanner.scan_all()
    recs = engine.generate_recommendations(items)
    assert len(recs) > 0

    # Ensure critical system apps are NOT recommended to be disabled
    for r in recs:
        assert "Windows Security" not in r.title
        assert "Realtek" not in r.title

    # Test dismissing a recommendation
    target_rec = recs[0]
    settings_mgr.dismiss_recommendation(target_rec.id)
    assert settings_mgr.is_recommendation_dismissed(target_rec.id) is True

    # After dismissal, it shouldn't show in active recommendations
    updated_recs = engine.generate_recommendations(items)
    rec_ids = [r.id for r in updated_recs]
    assert target_rec.id not in rec_ids

def test_health_evaluation(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr)
    engine = RecommendationsEngine(settings_mgr)

    items = scanner.scan_all()
    health = engine.evaluate_system_health(items)

    assert 40 <= health.score <= 100
    assert health.grade in ["Optimal", "Good", "Moderate Load", "Heavy Startup Load"]
    assert health.enabled_count > 0
    assert health.potential_savings_sec > 0

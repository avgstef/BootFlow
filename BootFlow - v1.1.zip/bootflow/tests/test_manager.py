import pytest
from app.core.scanner import StartupScanner
from app.core.manager import StartupManager
from app.core.settings import SettingsManager
from app.core.models import StartupStatus

def test_manager_toggle_item(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr)
    manager = StartupManager(settings_mgr)

    items = scanner.scan_all()
    target = next(i for i in items if i.name == "Spotify")
    initial_status = target.status

    # Toggle to Disabled
    success, msg = manager.set_item_status(target, False)
    assert success is True
    assert target.status == StartupStatus.DISABLED.value

    # Verify activity was logged
    activities = settings_mgr.get_recent_activity()
    assert len(activities) > 0
    assert "Spotify" in activities[0].action or "Spotify" in activities[0].details

    # Re-scan should reflect the persisted override
    refreshed_items = scanner.scan_all()
    refreshed_target = next(i for i in refreshed_items if i.name == "Spotify")
    assert refreshed_target.status == StartupStatus.DISABLED.value

    # Revert back to enabled
    success, msg = manager.revert_item_status(target)
    assert success is True
    assert target.status == StartupStatus.ENABLED.value

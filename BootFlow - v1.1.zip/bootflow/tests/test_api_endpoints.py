import pytest
from fastapi.testclient import TestClient
from app.server import app

client = TestClient(app)

def test_api_system_status():
    response = client.get("/api/system/status")
    assert response.status_code == 200
    data = response.json()
    assert "health" in data
    assert "score" in data["health"]
    assert "boot_stats" in data
    assert "phases" in data["boot_stats"]
    assert data["boot_stats"]["phases"]["bios_post_sec"] > 0

def test_api_startup_items():
    response = client.get("/api/startup/items")
    assert response.status_code == 200
    items = response.json()
    assert isinstance(items, list)
    assert len(items) > 0
    assert any(i["name"] == "Discord" for i in items)

def test_api_turbo_optimize():
    response = client.post("/api/tools/turbo-optimize")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "optimized" in data["message"].lower()

def test_api_delay_and_delete_flow():
    # Fetch active items first
    items_res = client.get("/api/startup/items")
    items = items_res.json()
    assert len(items) > 0

    target_for_delay = next((i for i in items if not i["is_system_critical"]), items[0])
    target_for_delete = next((i for i in items if not i["is_system_critical"] and i["id"] != target_for_delay["id"]), items[-1])

    # 1. Delay item
    response = client.post("/api/startup/delay", json={"item_id": target_for_delay["id"], "delay_seconds": 45})
    assert response.status_code == 200
    res = response.json()
    assert res["success"] is True

    # 2. Check items for delayed status
    items_after_delay = client.get("/api/startup/items").json()
    delayed_item = next((i for i in items_after_delay if i["id"] == target_for_delay["id"]), None)
    if delayed_item:
        assert delayed_item["is_delayed"] is True
        assert delayed_item["delay_seconds"] == 45

    # 3. Delete item
    del_res = client.post("/api/startup/delete", json={"item_id": target_for_delete["id"]})
    assert del_res.status_code == 200
    assert del_res.json()["success"] is True

    # 4. Verify target is removed
    items_after_del = client.get("/api/startup/items").json()
    assert not any(i["id"] == target_for_delete["id"] for i in items_after_del)

def test_api_diagnostics_export():
    response = client.get("/api/diagnostics/export")
    assert response.status_code == 200
    assert "text/csv" in response.headers.get("content-type", "")
    assert "Timestamp" in response.text

import pytest
from app.core.scanner import StartupScanner
from app.core.settings import SettingsManager
from app.core.models import StartupStatus, StartupImpact

def test_scanner_discovers_items(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr)
    items = scanner.scan_all()

    assert len(items) > 0
    names = [i.name for i in items]
    assert "Discord" in names
    assert "Spotify" in names
    assert "Microsoft OneDrive" in names

def test_scanner_heuristics_and_safety(tmp_path):
    settings_mgr = SettingsManager(data_dir=tmp_path)
    scanner = StartupScanner(settings_mgr)
    items = scanner.scan_all()

    discord = next(i for i in items if i.name == "Discord")
    assert discord.impact == StartupImpact.HIGH.value
    assert discord.startup_delay_ms > 1000
    assert not discord.is_system_critical

    security = next(i for i in items if "Security" in i.name)
    assert security.is_system_critical is True

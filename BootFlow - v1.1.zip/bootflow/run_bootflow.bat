@echo off
setlocal enabledelayedexpansion

:: =========================================================================
:: BootFlow - Quick Launcher for Windows
:: Checks for the built binary first, then falls back to python run.py
:: Ensures the window stays open on error with full diagnostics
:: =========================================================================

cd /d "%~dp0"

echo ============================================================
echo   BootFlow - Launching Application...
echo ============================================================
echo.

:: 1. Check if the compiled executable exists
if exist "dist\BootFlow\BootFlow.exe" (
    echo [OK] Found compiled BootFlow executable. Launching...
    start "" "dist\BootFlow\BootFlow.exe"
    exit /b 0
)

:: 2. If not compiled, locate Python and run from source
set "PY_CMD="
where py >nul 2>&1 && set "PY_CMD=py -3"
if not defined PY_CMD where python >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD where python3 >nul 2>&1 && set "PY_CMD=python3"

for %%V in (314 313 312 311 310 39) do (
    if not defined PY_CMD if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" set "PY_CMD="%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe""
    if not defined PY_CMD if exist "%ProgramFiles%\Python%%V\python.exe" set "PY_CMD="%ProgramFiles%\Python%%V\python.exe""
    if not defined PY_CMD if exist "C:\Python%%V\python.exe" set "PY_CMD="C:\Python%%V\python.exe""
)

if not defined PY_CMD (
    echo [ERROR] No compiled executable or Python installation found.
    echo Please run build.bat first to build the executable.
    pause
    exit /b 1
)

echo [OK] Launching BootFlow via Python (%PY_CMD%)...
%PY_CMD% run.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ============================================================
    echo [DIAGNOSTIC] BootFlow exited with status code: %ERRORLEVEL%
    if exist "bootflow_crash.log" (
        echo.
        echo Last crash log excerpt:
        type "bootflow_crash.log"
    )
    echo ============================================================
    echo.
    pause
)
